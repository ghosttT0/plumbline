from rentomatic import settings
from rentomatic.domain.storageroom import StorageRoom
from rentomatic.shared import use_case as uc
from rentomatic.shared import response_object as res


class StorageRoomListUseCase(uc.UseCase):

    def __init__(self, repo, currency_rates=None):
        self.repo = repo
        self.currency_rates = (
            currency_rates if currency_rates is not None
            else settings.Config.CURRENCY_RATES)

    def process_request(self, request_object):
        filters = request_object.filters
        if request_object.featured is not None:
            filters = dict(filters or {})
            filters['featured'] = request_object.featured

        # The room window [room_from, room_to] overlaps the requested
        # window [available_from, available_to] (inclusive) when the room
        # does not start after the requested end and does not end before
        # the requested start. Missing endpoints are unbounded.
        if request_object.available_from is not None:
            filters = dict(filters or {})
            filters['available_to__gte'] = request_object.available_from

        if request_object.available_to is not None:
            filters = dict(filters or {})
            filters['available_from__lte'] = request_object.available_to

        domain_storagerooms = self.repo.list(filters=filters)

        if request_object.sort == 'price_asc':
            domain_storagerooms = sorted(
                domain_storagerooms, key=lambda room: room.price)
        elif request_object.sort == 'price_desc':
            domain_storagerooms = sorted(
                domain_storagerooms, key=lambda room: room.price,
                reverse=True)

        page = request_object.page
        per_page = request_object.per_page
        start = (page - 1) * per_page
        page_storagerooms = domain_storagerooms[start:start + per_page]

        # when a display currency is requested, the stored price is
        # converted with the configured rate and rounded to 2 decimals;
        # each converted room advertises the currency it is shown in
        currency = request_object.currency
        if currency is not None:
            rate = self.currency_rates[currency]
            page_storagerooms = [
                StorageRoom.from_dict(
                    dict(room.to_dict(),
                         price=round(room.price * rate, 2),
                         currency=currency))
                for room in page_storagerooms
            ]

        return res.ResponseSuccess({
            'results': page_storagerooms,
            'page': page,
            'per_page': per_page,
            'total': len(domain_storagerooms),
        })
