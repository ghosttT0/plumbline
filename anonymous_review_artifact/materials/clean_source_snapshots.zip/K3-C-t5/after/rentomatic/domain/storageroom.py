from rentomatic.shared.domain_model import DomainModel


class StorageRoom(object):

    def __init__(self, code, size, price, latitude, longitude, featured=False,
                 available_from=None, available_to=None, currency=None):
        self.code = code
        self.size = size
        self.price = price
        self.latitude = latitude
        self.longitude = longitude
        self.featured = featured
        self.available_from = available_from
        self.available_to = available_to
        self.currency = currency

    @classmethod
    def from_dict(cls, adict):
        room = StorageRoom(
            code=adict['code'],
            size=adict['size'],
            price=adict['price'],
            latitude=adict['latitude'],
            longitude=adict['longitude'],
            featured=adict.get('featured', False),
            available_from=adict.get('available_from', None),
            available_to=adict.get('available_to', None),
            currency=adict.get('currency', None),
        )

        return room

    def to_dict(self):
        result = {
            'code': self.code,
            'size': self.size,
            'price': self.price,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'featured': self.featured,
        }

        # the availability window is optional: the keys are advertised
        # only when the room actually declares it
        if self.available_from is not None:
            result['available_from'] = self.available_from

        if self.available_to is not None:
            result['available_to'] = self.available_to

        # the currency is advertised only when the price has been
        # converted for display
        if self.currency is not None:
            result['currency'] = self.currency

        return result

    def __eq__(self, other):
        return self.to_dict() == other.to_dict()


DomainModel.register(StorageRoom)
