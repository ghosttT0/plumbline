import json


class StorageRoomEncoder(json.JSONEncoder):

    def default(self, o):
        try:
            to_serialize = {
                'code': str(o.code),
                'size': o.size,
                'price': o.price,
                'latitude': o.latitude,
                'longitude': o.longitude,
                'featured': o.featured,
            }

            if getattr(o, 'available_from', None) is not None:
                to_serialize['available_from'] = o.available_from

            if getattr(o, 'available_to', None) is not None:
                to_serialize['available_to'] = o.available_to

            if getattr(o, 'currency', None) is not None:
                to_serialize['currency'] = o.currency

            return to_serialize
        except AttributeError:
            return super().default(o)
