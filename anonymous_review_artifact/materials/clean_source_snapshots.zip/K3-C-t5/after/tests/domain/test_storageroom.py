import uuid
from rentomatic.domain.storageroom import StorageRoom


def test_storageroom_model_init():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=10,
                              longitude=-0.09998975,
                              latitude=51.75436293)
    assert storageroom.code == code
    assert storageroom.size == 200
    assert storageroom.price == 10
    assert storageroom.longitude == -0.09998975
    assert storageroom.latitude == 51.75436293
    assert storageroom.featured is False
    assert storageroom.available_from is None
    assert storageroom.available_to is None


def test_storageroom_model_init_with_featured():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=10,
                              longitude=-0.09998975,
                              latitude=51.75436293,
                              featured=True)
    assert storageroom.code == code
    assert storageroom.size == 200
    assert storageroom.price == 10
    assert storageroom.longitude == -0.09998975
    assert storageroom.latitude == 51.75436293
    assert storageroom.featured is True
    assert storageroom.available_from is None
    assert storageroom.available_to is None


def test_storageroom_model_init_with_availability_window():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=10,
                              longitude=-0.09998975,
                              latitude=51.75436293,
                              available_from='2026-11-01',
                              available_to='2026-11-15')
    assert storageroom.available_from == '2026-11-01'
    assert storageroom.available_to == '2026-11-15'


def test_storageroom_model_from_dict():
    code = uuid.uuid4()
    storageroom = StorageRoom.from_dict(
        {
            'code': code,
            'size': 200,
            'price': 10,
            'longitude': -0.09998975,
            'latitude': 51.75436293
        }
    )
    assert storageroom.code == code
    assert storageroom.size == 200
    assert storageroom.price == 10
    assert storageroom.longitude == -0.09998975
    assert storageroom.latitude == 51.75436293
    assert storageroom.featured is False
    assert storageroom.available_from is None
    assert storageroom.available_to is None


def test_storageroom_model_from_dict_with_featured():
    code = uuid.uuid4()
    storageroom = StorageRoom.from_dict(
        {
            'code': code,
            'size': 200,
            'price': 10,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'featured': True
        }
    )
    assert storageroom.code == code
    assert storageroom.size == 200
    assert storageroom.price == 10
    assert storageroom.longitude == -0.09998975
    assert storageroom.latitude == 51.75436293
    assert storageroom.featured is True
    assert storageroom.available_from is None
    assert storageroom.available_to is None


def test_storageroom_model_from_dict_with_availability_window():
    code = uuid.uuid4()
    storageroom = StorageRoom.from_dict(
        {
            'code': code,
            'size': 200,
            'price': 10,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'featured': True,
            'available_from': '2026-11-01',
            'available_to': '2026-11-15'
        }
    )
    assert storageroom.featured is True
    assert storageroom.available_from == '2026-11-01'
    assert storageroom.available_to == '2026-11-15'


def test_storageroom_model_to_dict():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': False
    }

    storageroom = StorageRoom.from_dict(storageroom_dict)

    assert storageroom.to_dict() == storageroom_dict


def test_storageroom_model_to_dict_with_availability_window():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': False,
        'available_from': '2026-11-01',
        'available_to': '2026-11-15'
    }

    storageroom = StorageRoom.from_dict(storageroom_dict)

    assert storageroom.to_dict() == storageroom_dict


def test_storageroom_model_to_dict_with_partial_availability_window():
    code = uuid.uuid4()
    storageroom = StorageRoom.from_dict(
        {
            'code': code,
            'size': 200,
            'price': 10,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'available_from': '2026-11-01'
        }
    )

    assert storageroom.to_dict() == {
        'code': code,
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': False,
        'available_from': '2026-11-01',
    }


def test_storageroom_model_comparison():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': True
    }
    storageroom1 = StorageRoom.from_dict(storageroom_dict)
    storageroom2 = StorageRoom.from_dict(storageroom_dict)

    assert storageroom1 == storageroom2


def test_storageroom_model_init_with_currency():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=42.12,
                              longitude=-0.09998975,
                              latitude=51.75436293,
                              currency='USD')
    assert storageroom.currency == 'USD'
    assert storageroom.price == 42.12


def test_storageroom_model_init_defaults_to_no_currency():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=10,
                              longitude=-0.09998975,
                              latitude=51.75436293)
    assert storageroom.currency is None


def test_storageroom_model_from_dict_with_currency():
    code = uuid.uuid4()
    storageroom = StorageRoom.from_dict(
        {
            'code': code,
            'size': 200,
            'price': 42.12,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'currency': 'USD'
        }
    )
    assert storageroom.currency == 'USD'
    assert storageroom.to_dict()['currency'] == 'USD'


def test_storageroom_model_to_dict_without_currency_omits_the_key():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=10,
                              longitude=-0.09998975,
                              latitude=51.75436293)

    assert 'currency' not in storageroom.to_dict()
