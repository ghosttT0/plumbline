import json
from unittest import mock

from rentomatic.shared import response_object as res

storageroom_stored_prices = {
    'f853578c-fc0f-4e65-81b8-566c5dffa35a': 39,
    'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a': 66,
    '913694c6-435a-4366-ba0d-da5334a611b2': 60,
    'eed76e77-55c1-41ce-985d-ca49bf6c0585': 48,
    '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a': 23,
}


def test_get_rooms_converted_to_usd(client):
    http_response = client.get('/storagerooms?currency=USD')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert len(body['results']) == 5

    expected_prices = {
        code: round(price * 1.08, 2)
        for code, price in storageroom_stored_prices.items()
    }
    for room in body['results']:
        assert room['currency'] == 'USD'
        assert room['price'] == expected_prices[room['code']]

    # spot check the conversion and the rounding to 2 decimals
    by_code = {room['code']: room for room in body['results']}
    assert by_code['f853578c-fc0f-4e65-81b8-566c5dffa35a']['price'] == 42.12
    assert by_code['fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a']['price'] == 71.28
    assert by_code['1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a']['price'] == 24.84


def test_get_rooms_converted_to_eur(client):
    http_response = client.get('/storagerooms?currency=EUR')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert len(body['results']) == 5

    by_code = {room['code']: room for room in body['results']}
    room1 = by_code['f853578c-fc0f-4e65-81b8-566c5dffa35a']
    assert room1['price'] == 39.0
    assert room1['currency'] == 'EUR'


def test_get_rooms_without_currency_keep_stored_prices(client):
    http_response = client.get('/storagerooms')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert len(body['results']) == 5
    for room in body['results']:
        assert 'currency' not in room
        assert room['price'] == \
            storageroom_stored_prices[room['code']]


def test_get_rooms_with_unsupported_currency_is_a_client_error(client):
    http_response = client.get('/storagerooms?currency=GBP')

    assert http_response.status_code == 400
    assert http_response.mimetype == 'application/json'

    body = json.loads(http_response.data.decode('UTF-8'))
    assert body['type'] == 'PARAMETERS_ERROR'
    # the message explains the problem and the supported currencies
    assert 'GBP' in body['message']
    assert 'USD' in body['message']
    assert 'EUR' in body['message']


def test_get_rooms_converted_currency_works_with_other_parameters(client):
    http_response = client.get(
        '/storagerooms?currency=USD&filter_price=66&page=1&per_page=1')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert body['total'] == 1
    assert len(body['results']) == 1
    assert body['results'][0]['code'] == \
        'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a'
    assert body['results'][0]['price'] == 71.28
    assert body['results'][0]['currency'] == 'USD'


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_currency(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?currency=USD')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'currency': 'USD'}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)
