import json
from unittest import mock

from rentomatic.domain.storageroom import StorageRoom
from rentomatic.shared import response_object as res

storageroom1_dict = {
    'code': '3251a5bd-86be-428d-8ae9-6e51a8048c33',
    'size': 200,
    'price': 10,
    'longitude': -0.09998975,
    'latitude': 51.75436293,
    'featured': False
}

storageroom1_domain_model = StorageRoom.from_dict(storageroom1_dict)

storagerooms = [storageroom1_domain_model]

seed_featured_codes = {
    'f853578c-fc0f-4e65-81b8-566c5dffa35a',
    'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
}

seed_non_featured_codes = {
    '913694c6-435a-4366-ba0d-da5334a611b2',
    'eed76e77-55c1-41ce-985d-ca49bf6c0585',
    '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',
}


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_get(mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess({
        'results': storagerooms,
        'page': 1,
        'per_page': 100,
        'total': 1,
    })

    http_response = client.get('/storagerooms')

    assert json.loads(http_response.data.decode(
        'UTF-8')) == {
        'results': [storageroom1_dict],
        'page': 1,
        'per_page': 100,
        'total': 1,
    }
    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_get_failed_response(mock_use_case, client):
    mock_use_case().execute.return_value = \
        res.ResponseFailure.build_system_error('test message')

    http_response = client.get('/storagerooms')

    assert json.loads(http_response.data.decode('UTF-8')) == \
        {'type': 'SYSTEM_ERROR', 'message': 'test message'}
    assert http_response.status_code == 500
    assert http_response.mimetype == 'application/json'


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_filters(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?filter_param1=value1&filter_param2=value2')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {'param1': 'value1', 'param2': 'value2'}}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_featured_true(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?featured=true')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'featured': True}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_featured_false(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?featured=false')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'featured': False}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_availability_window(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get(
            '/storagerooms?available_from=2026-11-01&available_to=2026-11-15')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'available_from': '2026-11-01',
         'available_to': '2026-11-15'}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_sort(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?sort=price_desc')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'sort': 'price_desc'}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_pagination(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?page=2&per_page=10')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'page': '2', 'per_page': '10'}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


def test_get_all_rooms_when_featured_parameter_is_absent(client):
    http_response = client.get('/storagerooms')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert body['page'] == 1
    assert body['per_page'] == 100
    assert body['total'] == 5
    assert len(body['results']) == 5
    assert set([room['code'] for room in body['results']]) == \
        seed_featured_codes | seed_non_featured_codes
    assert all('featured' in room for room in body['results'])


def test_get_all_rooms_advertise_their_availability(client):
    http_response = client.get('/storagerooms')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    by_code = {room['code']: room for room in body['results']}

    assert by_code['f853578c-fc0f-4e65-81b8-566c5dffa35a'][  # room1
        'available_from'] == '2026-11-01'
    assert by_code['f853578c-fc0f-4e65-81b8-566c5dffa35a'][  # room1
        'available_to'] == '2026-11-15'
    assert by_code['913694c6-435a-4366-ba0d-da5334a611b2'][  # room3
        'available_from'] == '2026-11-10'
    assert 'available_to' not in \
        by_code['913694c6-435a-4366-ba0d-da5334a611b2']
    assert 'available_from' not in \
        by_code['1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a']  # room5
    assert 'available_to' not in \
        by_code['1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a']


def test_get_featured_rooms(client):
    http_response = client.get('/storagerooms?featured=true')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert len(body['results']) == 2
    assert set([room['code'] for room in body['results']]) == \
        seed_featured_codes
    assert all(room['featured'] is True for room in body['results'])


def test_get_non_featured_rooms(client):
    http_response = client.get('/storagerooms?featured=false')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert len(body['results']) == 3
    assert set([room['code'] for room in body['results']]) == \
        seed_non_featured_codes
    assert all(room['featured'] is False for room in body['results'])


def test_get_rooms_with_featured_and_filters(client):
    http_response = client.get('/storagerooms?featured=true&filter_price=66')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert len(body['results']) == 1
    assert body['results'][0]['code'] == \
        'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a'
    assert body['results'][0]['featured'] is True


def test_get_rooms_available_in_window(client):
    http_response = client.get(
        '/storagerooms?available_from=2026-11-10&available_to=2026-11-20')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    # room2 ([2026-12-01, 2026-12-20]) does not overlap the window
    assert set([room['code'] for room in body['results']]) == {
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',   # [2026-11-01, 2026-11-15]
        '913694c6-435a-4366-ba0d-da5334a611b2',   # from 2026-11-10 on
        'eed76e77-55c1-41ce-985d-ca49bf6c0585',   # until 2026-11-30
        '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',   # no availability advertised
    }


def test_get_rooms_available_in_window_boundaries_are_inclusive(client):
    # the requested window touches room1 at its end and room2 at its start
    http_response = client.get(
        '/storagerooms?available_from=2026-11-15&available_to=2026-12-01')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert 'f853578c-fc0f-4e65-81b8-566c5dffa35a' in \
        [room['code'] for room in body['results']]
    assert 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a' in \
        [room['code'] for room in body['results']]
    assert len(body['results']) == 5


def test_get_rooms_available_after_date(client):
    http_response = client.get('/storagerooms?available_from=2026-12-01')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert set([room['code'] for room in body['results']]) == {
        'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',   # [2026-12-01, 2026-12-20]
        '913694c6-435a-4366-ba0d-da5334a611b2',   # from 2026-11-10 on
        '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',   # no availability advertised
    }


def test_get_rooms_available_before_date(client):
    http_response = client.get('/storagerooms?available_to=2026-11-20')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert set([room['code'] for room in body['results']]) == {
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',   # [2026-11-01, 2026-11-15]
        '913694c6-435a-4366-ba0d-da5334a611b2',   # from 2026-11-10 on
        'eed76e77-55c1-41ce-985d-ca49bf6c0585',   # until 2026-11-30
        '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',   # no availability advertised
    }


def test_get_rooms_available_in_disjoint_window(client):
    http_response = client.get(
        '/storagerooms?available_from=2027-01-10&available_to=2027-01-20')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    # only rooms with an unbounded availability side can match
    assert set([room['code'] for room in body['results']]) == {
        '913694c6-435a-4366-ba0d-da5334a611b2',
        '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',
    }


def test_get_with_availability_and_featured(client):
    http_response = client.get(
        '/storagerooms?featured=true&available_from=2026-11-10'
        '&available_to=2026-11-20')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert [room['code'] for room in body['results']] == \
        ['f853578c-fc0f-4e65-81b8-566c5dffa35a']


def test_get_with_malformed_available_from(client):
    http_response = client.get('/storagerooms?available_from=15/11/2026')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_from: Is not a valid ISO date (YYYY-MM-DD)'
    }


def test_get_with_malformed_available_to(client):
    http_response = client.get('/storagerooms?available_to=2026-02-30')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_to: Is not a valid ISO date (YYYY-MM-DD)'
    }


def test_get_with_malformed_availability_window(client):
    http_response = client.get(
        '/storagerooms?available_from=not-a-date&available_to=not-a-date')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_from: Is not a valid ISO date (YYYY-MM-DD)\n'
                   'available_to: Is not a valid ISO date (YYYY-MM-DD)'
    }


def test_get_rooms_sorted_by_price_asc(client):
    http_response = client.get('/storagerooms?sort=price_asc')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert [room['code'] for room in body['results']] == [
        '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',   # 23
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',   # 39
        'eed76e77-55c1-41ce-985d-ca49bf6c0585',   # 48
        '913694c6-435a-4366-ba0d-da5334a611b2',   # 60
        'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',   # 66
    ]
    assert [room['price'] for room in body['results']] == [23, 39, 48, 60, 66]


def test_get_rooms_sorted_by_price_desc(client):
    http_response = client.get('/storagerooms?sort=price_desc')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert [room['code'] for room in body['results']] == [
        'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',   # 66
        '913694c6-435a-4366-ba0d-da5334a611b2',   # 60
        'eed76e77-55c1-41ce-985d-ca49bf6c0585',   # 48
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',   # 39
        '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',   # 23
    ]
    assert [room['price'] for room in body['results']] == [66, 60, 48, 39, 23]


def test_get_rooms_sorted_within_a_filter(client):
    http_response = client.get('/storagerooms?featured=true&sort=price_desc')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert [room['code'] for room in body['results']] == [
        'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',   # 66
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',   # 39
    ]


def test_get_with_unknown_sort_value(client):
    http_response = client.get('/storagerooms?sort=prc_ascending')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'sort: Is not a valid sort value (price_asc, price_desc)'
    }


def test_get_with_sort_still_reports_validation_of_other_parameters(client):
    http_response = client.get(
        '/storagerooms?sort=unknown&available_from=2026-13-01')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_from: Is not a valid ISO date (YYYY-MM-DD)\n'
                   'sort: Is not a valid sort value (price_asc, price_desc)'
    }


def test_get_paginates_results(client):
    http_response = client.get('/storagerooms?per_page=2&page=2')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    # rooms keep their repository order: the second page holds room3 and room4
    assert [room['code'] for room in body['results']] == [
        '913694c6-435a-4366-ba0d-da5334a611b2',
        'eed76e77-55c1-41ce-985d-ca49bf6c0585',
    ]
    assert body['page'] == 2
    assert body['per_page'] == 2
    assert body['total'] == 5


def test_get_returns_the_last_partial_page(client):
    http_response = client.get('/storagerooms?per_page=2&page=3')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    # only the fifth room is left for the last page
    assert [room['code'] for room in body['results']] == \
        ['1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a']
    assert body['page'] == 3
    assert body['per_page'] == 2
    assert body['total'] == 5


def test_get_returns_an_empty_page_beyond_the_last_one(client):
    http_response = client.get('/storagerooms?per_page=5&page=2')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert body == {
        'results': [],
        'page': 2,
        'per_page': 5,
        'total': 5,
    }


def test_get_paginates_the_filtered_results(client):
    http_response = client.get('/storagerooms?featured=true&per_page=1&page=2')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert [room['code'] for room in body['results']] == \
        ['fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a']
    assert body['page'] == 2
    assert body['per_page'] == 1
    assert body['total'] == 2


def test_get_paginates_the_sorted_results(client):
    http_response = client.get('/storagerooms?sort=price_asc&per_page=2')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert [room['price'] for room in body['results']] == [23, 39]
    assert body['page'] == 1
    assert body['per_page'] == 2
    assert body['total'] == 5


def test_get_with_page_smaller_than_one(client):
    http_response = client.get('/storagerooms?page=0')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'page: Must be an integer greater than or equal to 1'
    }


def test_get_with_negative_page(client):
    http_response = client.get('/storagerooms?page=-3')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'page: Must be an integer greater than or equal to 1'
    }


def test_get_with_non_integer_page(client):
    http_response = client.get('/storagerooms?page=first')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'page: Must be an integer greater than or equal to 1'
    }


def test_get_with_per_page_smaller_than_one(client):
    http_response = client.get('/storagerooms?per_page=0')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'per_page: Must be an integer between 1 and 100'
    }


def test_get_with_per_page_greater_than_one_hundred(client):
    http_response = client.get('/storagerooms?per_page=101')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'per_page: Must be an integer between 1 and 100'
    }


def test_get_with_non_integer_per_page(client):
    http_response = client.get('/storagerooms?per_page=many')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'per_page: Must be an integer between 1 and 100'
    }


def test_get_with_invalid_page_and_per_page_reports_both(client):
    http_response = client.get('/storagerooms?page=0&per_page=0')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'page: Must be an integer greater than or equal to 1\n'
                   'per_page: Must be an integer between 1 and 100'
    }
