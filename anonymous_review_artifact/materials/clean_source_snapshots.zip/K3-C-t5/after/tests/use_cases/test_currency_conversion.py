import uuid
from unittest import mock

from rentomatic.domain.storageroom import StorageRoom
from rentomatic.use_cases import request_objects as req
from rentomatic.use_cases import storageroom_use_cases as uc

CURRENCY_RATES = {'EUR': 1.0, 'USD': 1.08}


def _storageroom(code, price):
    return StorageRoom(
        code=code,
        size=100,
        price=price,
        longitude=-0.09998975,
        latitude=51.75436293,
    )


def test_request_object_accepts_supported_currencies():
    for currency in ('EUR', 'USD'):
        request_object = req.StorageRoomListRequestObject.from_dict(
            {'currency': currency})

        assert bool(request_object) is True
        assert request_object.currency == currency


def test_request_object_has_no_currency_by_default():
    request_object = req.StorageRoomListRequestObject.from_dict({})

    assert bool(request_object) is True
    assert request_object.currency is None


def test_request_object_rejects_unsupported_currency():
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'currency': 'GBP'})

    assert bool(request_object) is False
    assert request_object.errors[0]['parameter'] == 'currency'
    # the error explains what went wrong and what is supported
    assert 'GBP' in request_object.errors[0]['message']
    assert 'USD' in request_object.errors[0]['message']
    assert 'EUR' in request_object.errors[0]['message']


def test_use_case_converts_prices_to_the_requested_currency():
    stored_rooms = [_storageroom('code-a', 39), _storageroom('code-b', 66)]
    repo = mock.Mock()
    repo.list.return_value = list(stored_rooms)

    use_case = uc.StorageRoomListUseCase(repo, currency_rates=CURRENCY_RATES)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'currency': 'USD'})

    response = use_case.execute(request_object)

    assert bool(response) is True
    converted_rooms = response.value['results']
    # the stored prices are converted with the configured rate
    assert [room.price for room in converted_rooms] == [42.12, 71.28]
    assert [room.currency for room in converted_rooms] == ['USD', 'USD']
    # the stored rooms keep their original price and have no currency
    assert [room.price for room in stored_rooms] == [39, 66]
    assert all(room.currency is None for room in stored_rooms)


def test_use_case_rounds_converted_prices_to_two_decimals():
    repo = mock.Mock()
    repo.list.return_value = [_storageroom('code-a', 33)]

    use_case = uc.StorageRoomListUseCase(repo, currency_rates=CURRENCY_RATES)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'currency': 'USD'})

    response = use_case.execute(request_object)

    assert response.value['results'][0].price == 35.64


def test_use_case_defaults_to_the_rates_in_the_application_settings():
    repo = mock.Mock()
    repo.list.return_value = [_storageroom('code-a', 39)]

    use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'currency': 'EUR'})

    response = use_case.execute(request_object)

    converted_room = response.value['results'][0]
    assert converted_room.price == 39.0
    assert converted_room.currency == 'EUR'


def test_use_case_keeps_prices_unchanged_without_currency():
    stored_room = _storageroom(uuid.uuid4(), 39)
    repo = mock.Mock()
    repo.list.return_value = [stored_room]

    use_case = uc.StorageRoomListUseCase(repo, currency_rates=CURRENCY_RATES)
    request_object = req.StorageRoomListRequestObject.from_dict({})

    response = use_case.execute(request_object)

    assert bool(response) is True
    results = response.value['results']
    assert results == [stored_room]
    assert all('currency' not in room.to_dict() for room in results)


def test_use_case_converts_only_the_requested_page():
    stored_rooms = [
        _storageroom('code-a', 39),
        _storageroom('code-b', 66),
    ]
    repo = mock.Mock()
    repo.list.return_value = list(stored_rooms)

    use_case = uc.StorageRoomListUseCase(repo, currency_rates=CURRENCY_RATES)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'currency': 'USD', 'page': 2, 'per_page': 1})

    response = use_case.execute(request_object)

    assert response.value['total'] == 2
    assert [room.code for room in response.value['results']] == ['code-b']
    assert response.value['results'][0].price == 71.28
    assert response.value['results'][0].currency == 'USD'
