import datetime

from rentomatic.use_cases import request_objects as ro


def test_build_storageroom_list_request_object_without_parameters():
    req = ro.StorageRoomListRequestObject()

    assert req.filters is None
    assert req.featured is None
    assert req.available_from is None
    assert req.available_to is None
    assert req.sort is None
    assert req.page == 1
    assert req.per_page == 100
    assert bool(req) is True


def test_build_file_list_request_object_from_empty_dict():
    req = ro.StorageRoomListRequestObject.from_dict({})

    assert req.filters is None
    assert req.featured is None
    assert req.available_from is None
    assert req.available_to is None
    assert req.sort is None
    assert req.page == 1
    assert req.per_page == 100
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_empty_filters():
    req = ro.StorageRoomListRequestObject(filters={})

    assert req.filters == {}
    assert req.featured is None
    assert req.available_from is None
    assert req.available_to is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_empty_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': {}})

    assert req.filters == {}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_filters():
    req = ro.StorageRoomListRequestObject(filters={'a': 1, 'b': 2})

    assert req.filters == {'a': 1, 'b': 2}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': {'a': 1, 'b': 2}})

    assert req.filters == {'a': 1, 'b': 2}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': 5})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'filters'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_featured():
    req = ro.StorageRoomListRequestObject(featured=True)

    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_featured():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': True})

    assert req.filters is None
    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_featured_false():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': False})

    assert req.featured is False
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_filters_and_featured():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 60}, 'featured': True})

    assert req.filters == {'price__lt': 60}
    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_featured():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': 'true'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'featured'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_available_from():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01'})

    assert bool(req) is True
    assert req.available_from == datetime.date(2026, 11, 1)
    assert req.available_to is None


def test_build_storageroom_list_request_object_from_dict_with_available_to():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_to': '2026-11-15'})

    assert bool(req) is True
    assert req.available_from is None
    assert req.available_to == datetime.date(2026, 11, 15)


def test_build_storageroom_list_request_object_from_dict_with_availability_window():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01', 'available_to': '2026-11-15'})

    assert bool(req) is True
    assert req.available_from == datetime.date(2026, 11, 1)
    assert req.available_to == datetime.date(2026, 11, 15)


def test_build_storageroom_list_request_object_with_availability_window():
    req = ro.StorageRoomListRequestObject(
        available_from=datetime.date(2026, 11, 1),
        available_to=datetime.date(2026, 11, 15))

    assert req.available_from == datetime.date(2026, 11, 1)
    assert req.available_to == datetime.date(2026, 11, 15)
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_malformed_available_from():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '15/11/2026'})

    assert req.has_errors()
    assert req.errors == [{
        'parameter': 'available_from',
        'message': 'Is not a valid ISO date (YYYY-MM-DD)'
    }]
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_malformed_available_to():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_to': 'not-a-date'})

    assert req.has_errors()
    assert req.errors == [{
        'parameter': 'available_to',
        'message': 'Is not a valid ISO date (YYYY-MM-DD)'
    }]
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_invalid_calendar_date():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-02-30'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_zero_padded_date():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-1'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_string_date():
    req = ro.StorageRoomListRequestObject.from_dict({'available_from': 20261101})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert bool(req) is False


def test_build_storageroom_list_request_object_accumulates_malformed_dates():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': 'foo', 'available_to': 'bar'})

    assert req.has_errors()
    assert [err['parameter'] for err in req.errors] == \
        ['available_from', 'available_to']
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_sort_price_asc():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'price_asc'})

    assert bool(req) is True
    assert req.sort == 'price_asc'


def test_build_storageroom_list_request_object_with_sort_price_desc():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'price_desc'})

    assert bool(req) is True
    assert req.sort == 'price_desc'


def test_build_storageroom_list_request_object_with_sort_and_other_parameters():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 60}, 'featured': True,
         'available_from': '2026-11-01', 'sort': 'price_desc'})

    assert bool(req) is True
    assert req.filters == {'price__lt': 60}
    assert req.featured is True
    assert req.available_from == datetime.date(2026, 11, 1)
    assert req.sort == 'price_desc'


def test_build_storageroom_list_request_object_from_dict_with_invalid_sort():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'unknown'})

    assert req.has_errors()
    assert req.errors == [{
        'parameter': 'sort',
        'message': 'Is not a valid sort value (price_asc, price_desc)'
    }]
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_empty_sort():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': ''})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'sort'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_pagination_parameters():
    req = ro.StorageRoomListRequestObject(page=2, per_page=10)

    assert req.page == 2
    assert req.per_page == 10
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_page_and_per_page():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'page': '3', 'per_page': '25'})

    assert bool(req) is True
    assert req.page == 3
    assert req.per_page == 25


def test_build_storageroom_list_request_object_from_dict_with_integer_page_and_per_page():
    req = ro.StorageRoomListRequestObject.from_dict({'page': 3, 'per_page': 25})

    assert bool(req) is True
    assert req.page == 3
    assert req.per_page == 25


def test_build_storageroom_list_request_object_from_dict_with_page_only_keeps_default_per_page():
    req = ro.StorageRoomListRequestObject.from_dict({'page': '2'})

    assert bool(req) is True
    assert req.page == 2
    assert req.per_page == 100


def test_build_storageroom_list_request_object_from_dict_with_per_page_only_keeps_default_page():
    req = ro.StorageRoomListRequestObject.from_dict({'per_page': '10'})

    assert bool(req) is True
    assert req.page == 1
    assert req.per_page == 10


def test_build_storageroom_list_request_object_accepts_per_page_boundaries():
    req = ro.StorageRoomListRequestObject.from_dict({'per_page': '1'})
    assert bool(req) is True
    assert req.per_page == 1

    req = ro.StorageRoomListRequestObject.from_dict({'per_page': '100'})
    assert bool(req) is True
    assert req.per_page == 100


def test_build_storageroom_list_request_object_from_dict_with_zero_page():
    req = ro.StorageRoomListRequestObject.from_dict({'page': '0'})

    assert req.has_errors()
    assert req.errors == [{
        'parameter': 'page',
        'message': 'Must be an integer greater than or equal to 1'
    }]
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_negative_page():
    req = ro.StorageRoomListRequestObject.from_dict({'page': '-2'})

    assert req.has_errors()
    assert req.errors == [{
        'parameter': 'page',
        'message': 'Must be an integer greater than or equal to 1'
    }]
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_integer_page():
    req = ro.StorageRoomListRequestObject.from_dict({'page': 'first'})

    assert req.has_errors()
    assert req.errors == [{
        'parameter': 'page',
        'message': 'Must be an integer greater than or equal to 1'
    }]
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_zero_per_page():
    req = ro.StorageRoomListRequestObject.from_dict({'per_page': '0'})

    assert req.has_errors()
    assert req.errors == [{
        'parameter': 'per_page',
        'message': 'Must be an integer between 1 and 100'
    }]
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_too_large_per_page():
    req = ro.StorageRoomListRequestObject.from_dict({'per_page': '101'})

    assert req.has_errors()
    assert req.errors == [{
        'parameter': 'per_page',
        'message': 'Must be an integer between 1 and 100'
    }]
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_integer_per_page():
    req = ro.StorageRoomListRequestObject.from_dict({'per_page': 'ten'})

    assert req.has_errors()
    assert req.errors == [{
        'parameter': 'per_page',
        'message': 'Must be an integer between 1 and 100'
    }]
    assert bool(req) is False


def test_build_storageroom_list_request_object_accumulates_pagination_errors():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'page': '0', 'per_page': '1000'})

    assert req.has_errors()
    assert [err['parameter'] for err in req.errors] == ['page', 'per_page']
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_pagination_and_other_parameters():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 60}, 'featured': True,
         'sort': 'price_asc', 'page': '2', 'per_page': '5'})

    assert bool(req) is True
    assert req.filters == {'price__lt': 60}
    assert req.featured is True
    assert req.sort == 'price_asc'
    assert req.page == 2
    assert req.per_page == 5
