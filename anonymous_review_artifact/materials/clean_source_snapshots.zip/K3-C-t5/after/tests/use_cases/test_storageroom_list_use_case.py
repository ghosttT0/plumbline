import datetime
import uuid

import pytest
from unittest import mock

from rentomatic.domain.storageroom import StorageRoom
from rentomatic.shared import response_object as res
from rentomatic.repository import memrepo
from rentomatic.use_cases import request_objects as req
from rentomatic.use_cases import storageroom_use_cases as uc


@pytest.fixture
def domain_storagerooms():
    storageroom_1 = StorageRoom(
        code=uuid.uuid4(),
        size=215,
        price=39,
        longitude=-0.09998975,
        latitude=51.75436293,
    )

    storageroom_2 = StorageRoom(
        code=uuid.uuid4(),
        size=405,
        price=66,
        longitude=0.18228006,
        latitude=51.74640997,
    )

    storageroom_3 = StorageRoom(
        code=uuid.uuid4(),
        size=56,
        price=60,
        longitude=0.27891577,
        latitude=51.45994069,
    )

    storageroom_4 = StorageRoom(
        code=uuid.uuid4(),
        size=93,
        price=48,
        longitude=0.33894476,
        latitude=51.39916678,
    )

    return [storageroom_1, storageroom_2, storageroom_3, storageroom_4]


def test_storageroom_list_without_parameters(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters=None)

    assert response_object.value == {
        'results': domain_storagerooms,
        'page': 1,
        'per_page': 100,
        'total': 4,
    }


def test_storageroom_list_with_filters(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    qry_filters = {'a': 5}
    request_object = req.StorageRoomListRequestObject.from_dict({'filters': qry_filters})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters=qry_filters)
    assert response_object.value == {
        'results': domain_storagerooms,
        'page': 1,
        'per_page': 100,
        'total': 4,
    }


def test_storageroom_list_with_featured_true(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({'featured': True})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters={'featured': True})
    assert response_object.value == {
        'results': domain_storagerooms,
        'page': 1,
        'per_page': 100,
        'total': 4,
    }


def test_storageroom_list_with_featured_false(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({'featured': False})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters={'featured': False})
    assert response_object.value == {
        'results': domain_storagerooms,
        'page': 1,
        'per_page': 100,
        'total': 4,
    }


def test_storageroom_list_with_featured_and_filters(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    qry_filters = {'price__lt': 60}
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'filters': qry_filters, 'featured': True})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters={'price__lt': 60, 'featured': True})
    assert response_object.value == {
        'results': domain_storagerooms,
        'page': 1,
        'per_page': 100,
        'total': 4,
    }


def test_storageroom_list_with_availability_window(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01', 'available_to': '2026-11-15'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    # the room window must not end before the requested start and must not
    # start after the requested end (inclusive overlap)
    repo.list.assert_called_with(filters={
        'available_to__gte': datetime.date(2026, 11, 1),
        'available_from__lte': datetime.date(2026, 11, 15),
    })
    assert response_object.value == {
        'results': domain_storagerooms,
        'page': 1,
        'per_page': 100,
        'total': 4,
    }


def test_storageroom_list_with_available_from_only(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'available_to__gte': datetime.date(2026, 11, 1)})
    assert response_object.value == {
        'results': domain_storagerooms,
        'page': 1,
        'per_page': 100,
        'total': 4,
    }


def test_storageroom_list_with_available_to_only(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'available_to': '2026-11-15'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'available_from__lte': datetime.date(2026, 11, 15)})
    assert response_object.value == {
        'results': domain_storagerooms,
        'page': 1,
        'per_page': 100,
        'total': 4,
    }


def test_storageroom_list_with_featured_filters_and_availability(
        domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 60},
         'featured': True,
         'available_from': '2026-11-01',
         'available_to': '2026-11-15'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters={
        'price__lt': 60,
        'featured': True,
        'available_to__gte': datetime.date(2026, 11, 1),
        'available_from__lte': datetime.date(2026, 11, 15),
    })
    assert response_object.value == {
        'results': domain_storagerooms,
        'page': 1,
        'per_page': 100,
        'total': 4,
    }


def test_storageroom_list_paginates_results():
    rooms = [
        {'code': 'code-a', 'size': 100, 'price': 66,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-b', 'size': 100, 'price': 23,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-c', 'size': 100, 'price': 48,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-d', 'size': 100, 'price': 60,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-e', 'size': 100, 'price': 39,
         'longitude': -0.09998975, 'latitude': 51.75436293},
    ]
    repo = memrepo.MemRepo(rooms)

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'page': 2, 'per_page': 2})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    # the second page holds the third and fourth rooms
    assert [r.code for r in response_object.value['results']] == \
        ['code-c', 'code-d']
    assert response_object.value['page'] == 2
    assert response_object.value['per_page'] == 2
    assert response_object.value['total'] == 5


def test_storageroom_list_returns_last_partial_page():
    rooms = [
        {'code': 'code-a', 'size': 100, 'price': 66,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-b', 'size': 100, 'price': 23,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-c', 'size': 100, 'price': 48,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-d', 'size': 100, 'price': 60,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-e', 'size': 100, 'price': 39,
         'longitude': -0.09998975, 'latitude': 51.75436293},
    ]
    repo = memrepo.MemRepo(rooms)

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'page': 3, 'per_page': 2})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    # the last page holds only the remaining room
    assert [r.code for r in response_object.value['results']] == ['code-e']
    assert response_object.value['page'] == 3
    assert response_object.value['per_page'] == 2
    assert response_object.value['total'] == 5


def test_storageroom_list_returns_empty_results_for_page_beyond_the_last():
    rooms = [
        {'code': 'code-a', 'size': 100, 'price': 66,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-b', 'size': 100, 'price': 23,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-c', 'size': 100, 'price': 48,
         'longitude': -0.09998975, 'latitude': 51.75436293},
    ]
    repo = memrepo.MemRepo(rooms)

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'page': 4, 'per_page': 2})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert response_object.value == {
        'results': [],
        'page': 4,
        'per_page': 2,
        'total': 3,
    }


def test_storageroom_list_total_counts_all_filtered_results():
    featured_room = {
        'code': 'code-a', 'size': 100, 'price': 23,
        'longitude': -0.09998975, 'latitude': 51.75436293,
        'featured': True,
    }
    another_featured_room = {
        'code': 'code-b', 'size': 100, 'price': 66,
        'longitude': 0.18228006, 'latitude': 51.74640997,
        'featured': True,
    }
    non_featured_room = {
        'code': 'code-c', 'size': 100, 'price': 48,
        'longitude': 0.27891577, 'latitude': 51.45994069,
        'featured': False,
    }
    repo = memrepo.MemRepo(
        [featured_room, another_featured_room, non_featured_room])

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'featured': True, 'page': 2, 'per_page': 1})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    # the second page of the featured rooms holds the second one, but the
    # total still counts every featured room
    assert [r.code for r in response_object.value['results']] == ['code-b']
    assert response_object.value['page'] == 2
    assert response_object.value['per_page'] == 1
    assert response_object.value['total'] == 2


def test_storageroom_list_applies_pagination_after_sorting():
    rooms = [
        {'code': 'code-a', 'size': 100, 'price': 66,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-b', 'size': 100, 'price': 23,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-c', 'size': 100, 'price': 48,
         'longitude': -0.09998975, 'latitude': 51.75436293},
    ]
    repo = memrepo.MemRepo(rooms)

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'sort': 'price_asc', 'page': 1, 'per_page': 2})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert [r.code for r in response_object.value['results']] == \
        ['code-b', 'code-c']
    assert [r.price for r in response_object.value['results']] == [23, 48]
    assert response_object.value['total'] == 3


def test_storageroom_list_availability_overlap_is_inclusive():
    # the room is available exactly in [2026-11-01, 2026-11-15]
    room_dict = {
        'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
        'size': 215,
        'price': 39,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'available_from': '2026-11-01',
        'available_to': '2026-11-15',
    }
    repo = memrepo.MemRepo([room_dict])

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)

    # a requested window sharing a single boundary still matches
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-15', 'available_to': '2026-11-20'})
    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert [r.code for r in response_object.value['results']] == \
        [room_dict['code']]

    # a window starting one day after the room availability ends does not
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-16', 'available_to': '2026-11-20'})
    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert response_object.value['results'] == []


def test_storageroom_list_returns_only_featured_rooms():
    featured_room_dict = {
        'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
        'size': 215,
        'price': 39,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': True,
    }
    non_featured_room_dict = {
        'code': 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
        'size': 405,
        'price': 66,
        'longitude': 0.18228006,
        'latitude': 51.74640997,
        'featured': False,
    }
    repo = memrepo.MemRepo([featured_room_dict, non_featured_room_dict])

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({'featured': True})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert [r.code for r in response_object.value['results']] == \
        [featured_room_dict['code']]


def test_storageroom_list_returns_only_non_featured_rooms():
    featured_room_dict = {
        'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
        'size': 215,
        'price': 39,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': True,
    }
    non_featured_room_dict = {
        'code': 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
        'size': 405,
        'price': 66,
        'longitude': 0.18228006,
        'latitude': 51.74640997,
        'featured': False,
    }
    repo = memrepo.MemRepo([featured_room_dict, non_featured_room_dict])

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({'featured': False})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert [r.code for r in response_object.value['results']] == \
        [non_featured_room_dict['code']]


def test_storageroom_list_without_sort_keeps_repository_order():
    rooms = [
        {'code': 'code-a', 'size': 100, 'price': 66,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-b', 'size': 100, 'price': 23,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-c', 'size': 100, 'price': 48,
         'longitude': -0.09998975, 'latitude': 51.75436293},
    ]
    repo = memrepo.MemRepo(rooms)

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert [r.code for r in response_object.value['results']] == \
        ['code-a', 'code-b', 'code-c']


def test_storageroom_list_sorts_by_price_ascending():
    rooms = [
        {'code': 'code-a', 'size': 100, 'price': 66,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-b', 'size': 100, 'price': 23,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-c', 'size': 100, 'price': 48,
         'longitude': -0.09998975, 'latitude': 51.75436293},
    ]
    repo = memrepo.MemRepo(rooms)

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'sort': 'price_asc'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert [r.code for r in response_object.value['results']] == \
        ['code-b', 'code-c', 'code-a']
    assert [r.price for r in response_object.value['results']] == [23, 48, 66]


def test_storageroom_list_sorts_by_price_descending():
    rooms = [
        {'code': 'code-a', 'size': 100, 'price': 66,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-b', 'size': 100, 'price': 23,
         'longitude': -0.09998975, 'latitude': 51.75436293},
        {'code': 'code-c', 'size': 100, 'price': 48,
         'longitude': -0.09998975, 'latitude': 51.75436293},
    ]
    repo = memrepo.MemRepo(rooms)

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'sort': 'price_desc'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert [r.code for r in response_object.value['results']] == \
        ['code-a', 'code-c', 'code-b']
    assert [r.price for r in response_object.value['results']] == [66, 48, 23]


def test_storageroom_list_sorts_the_filtered_result():
    featured_room = {
        'code': 'code-a', 'size': 100, 'price': 23,
        'longitude': -0.09998975, 'latitude': 51.75436293,
        'featured': True,
    }
    another_featured_room = {
        'code': 'code-b', 'size': 100, 'price': 66,
        'longitude': 0.18228006, 'latitude': 51.74640997,
        'featured': True,
    }
    non_featured_room = {
        'code': 'code-c', 'size': 100, 'price': 48,
        'longitude': 0.27891577, 'latitude': 51.45994069,
        'featured': False,
    }
    repo = memrepo.MemRepo(
        [featured_room, another_featured_room, non_featured_room])

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'featured': True, 'sort': 'price_desc'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert [r.code for r in response_object.value['results']] == \
        ['code-b', 'code-a']


def test_storageroom_list_handles_generic_error():
    repo = mock.Mock()
    repo.list.side_effect = Exception('Just an error message')

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    assert response_object.value == {
        'type': res.ResponseFailure.SYSTEM_ERROR,
        'message': "Exception: Just an error message"
    }


def test_storageroom_list_handles_bad_request():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({'filters': 5})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': "filters: Is not iterable"
    }
