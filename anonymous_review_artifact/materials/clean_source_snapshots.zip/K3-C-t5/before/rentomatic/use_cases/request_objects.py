import collections.abc
import datetime
import re

from rentomatic.shared import request_object as req

_ISO_DATE_REGEX = re.compile(r'^\d{4}-\d{2}-\d{2}$')

VALID_SORT_VALUES = ('price_asc', 'price_desc')

DEFAULT_PAGE = 1
MIN_PER_PAGE = 1
MAX_PER_PAGE = 100
DEFAULT_PER_PAGE = MAX_PER_PAGE

PAGE_ERROR_MESSAGE = 'Must be an integer greater than or equal to 1'
PER_PAGE_ERROR_MESSAGE = 'Must be an integer between 1 and 100'


def parse_iso_date(value):
    """Parse a strictly-formatted ISO date string (YYYY-MM-DD).

    Returns a ``datetime.date`` or ``None`` when the value is not a
    valid ISO date.
    """
    if not isinstance(value, str) or not _ISO_DATE_REGEX.match(value):
        return None

    try:
        return datetime.datetime.strptime(value, '%Y-%m-%d').date()
    except ValueError:
        return None


def parse_integer(value):
    """Coerce a value into an ``int`` (returns None when impossible).

    Query-string values arrive as strings, so both integers and their
    string representations are accepted.
    """
    if isinstance(value, bool):
        return None

    if isinstance(value, int):
        return value

    if isinstance(value, str):
        try:
            return int(value)
        except ValueError:
            return None

    return None


class StorageRoomListRequestObject(req.ValidRequestObject):

    def __init__(self, filters=None, featured=None,
                 available_from=None, available_to=None, sort=None,
                 page=DEFAULT_PAGE, per_page=DEFAULT_PER_PAGE):
        self.filters = filters
        self.featured = featured
        self.available_from = available_from
        self.available_to = available_to
        self.sort = sort
        self.page = page
        self.per_page = per_page

    @classmethod
    def from_dict(cls, adict):
        invalid_req = req.InvalidRequestObject()

        if 'filters' in adict and not isinstance(adict['filters'], collections.abc.Mapping):
            invalid_req.add_error('filters', 'Is not iterable')

        if 'featured' in adict and not isinstance(adict['featured'], bool):
            invalid_req.add_error('featured', 'Is not a boolean')

        parsed_dates = {}
        for param in ['available_from', 'available_to']:
            if adict.get(param, None) is not None:
                parsed_dates[param] = parse_iso_date(adict[param])
                if parsed_dates[param] is None:
                    invalid_req.add_error(
                        param, 'Is not a valid ISO date (YYYY-MM-DD)')

        sort = adict.get('sort', None)
        if sort is not None and sort not in VALID_SORT_VALUES:
            invalid_req.add_error(
                'sort',
                'Is not a valid sort value ({})'.format(
                    ', '.join(VALID_SORT_VALUES)))

        page = DEFAULT_PAGE
        raw_page = adict.get('page', None)
        if raw_page is not None:
            page = parse_integer(raw_page)
            if page is None or page < 1:
                invalid_req.add_error('page', PAGE_ERROR_MESSAGE)

        per_page = DEFAULT_PER_PAGE
        raw_per_page = adict.get('per_page', None)
        if raw_per_page is not None:
            per_page = parse_integer(raw_per_page)
            if per_page is None or \
                    not MIN_PER_PAGE <= per_page <= MAX_PER_PAGE:
                invalid_req.add_error('per_page', PER_PAGE_ERROR_MESSAGE)

        if invalid_req.has_errors():
            return invalid_req

        return StorageRoomListRequestObject(
            filters=adict.get('filters', None),
            featured=adict.get('featured', None),
            available_from=parsed_dates.get('available_from', None),
            available_to=parsed_dates.get('available_to', None),
            sort=sort,
            page=page,
            per_page=per_page
        )
