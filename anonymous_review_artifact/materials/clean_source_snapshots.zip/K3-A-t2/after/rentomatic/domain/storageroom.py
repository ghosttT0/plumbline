import re
from datetime import datetime

from rentomatic.shared.domain_model import DomainModel

ISO_DATE_PATTERN = re.compile(r'\d{4}-\d{2}-\d{2}\Z')


def parse_iso_date(value):
    """Parse an ISO date string (YYYY-MM-DD) into a ``datetime.date``.

    Raises ``ValueError`` when the value is not a string or is not a valid
    ISO date in strict YYYY-MM-DD format.
    """
    if not isinstance(value, str) or not ISO_DATE_PATTERN.match(value):
        raise ValueError(
            'Not a valid ISO date (YYYY-MM-DD): {}'.format(value))

    return datetime.strptime(value, '%Y-%m-%d').date()


class StorageRoom(object):

    def __init__(self, code, size, price, latitude, longitude, featured=False,
                 available_from=None, available_to=None):
        self.code = code
        self.size = size
        self.price = price
        self.latitude = latitude
        self.longitude = longitude
        self.featured = featured
        self.available_from = available_from
        self.available_to = available_to

    @classmethod
    def from_dict(cls, adict):
        room = StorageRoom(
            code=adict['code'],
            size=adict['size'],
            price=adict['price'],
            latitude=adict['latitude'],
            longitude=adict['longitude'],
            featured=adict.get('featured', False),
            available_from=adict.get('available_from', None),
            available_to=adict.get('available_to', None),
        )

        return room

    def to_dict(self):
        room_dict = {
            'code': self.code,
            'size': self.size,
            'price': self.price,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'featured': self.featured,
        }

        if self.available_from is not None:
            room_dict['available_from'] = self.available_from

        if self.available_to is not None:
            room_dict['available_to'] = self.available_to

        return room_dict

    def __eq__(self, other):
        return self.to_dict() == other.to_dict()

    @staticmethod
    def window_overlaps(room_available_from, room_available_to,
                        requested_from, requested_to):
        """Return True when a room's advertised availability window overlaps
        the requested window, boundary dates included.

        All arguments are ISO date strings (YYYY-MM-DD); either bound of the
        requested window may be None, meaning "unbounded" on that side.
        A room that does not advertise both ends of its window can never
        overlap a requested window.

        Raises ``ValueError`` when a provided date is not a valid ISO date.
        """
        if room_available_from is None or room_available_to is None:
            return False

        room_from = parse_iso_date(room_available_from)
        room_to = parse_iso_date(room_available_to)

        if requested_from is not None and \
                room_to < parse_iso_date(requested_from):
            return False

        if requested_to is not None and \
                room_from > parse_iso_date(requested_to):
            return False

        return True


DomainModel.register(StorageRoom)
