from rentomatic.domain import storageroom as sr


class MemRepo:

    def __init__(self, entries=None):
        self._entries = []
        if entries:
            self._entries.extend(entries)

    @staticmethod
    def _to_bool(value):
        if isinstance(value, bool):
            return value

        return str(value).strip().lower() == 'true'

    def _check(self, element, key, value):
        if '__' not in key:
            key = key + '__eq'

        key, operator = key.split('__')

        if operator not in ['eq', 'lt', 'gt']:
            raise ValueError('Operator {} is not supported'.format(operator))

        operator = '__{}__'.format(operator)

        if key in ['size', 'price']:
            return getattr(element[key], operator)(int(value))
        elif key in ['latitude', 'longitude']:
            return getattr(element[key], operator)(float(value))
        elif key == 'featured':
            return element.get('featured', False).__eq__(self._to_bool(value))

        return getattr(element[key], operator)(value)

    def list(self, filters=None, available_from=None, available_to=None):
        if not filters:
            result = self._entries
        else:
            result = []
            result.extend(self._entries)

            for key, value in filters.items():
                result = [e for e in result if self._check(e, key, value)]

        if available_from is not None or available_to is not None:
            result = [
                e for e in result
                if sr.StorageRoom.window_overlaps(
                    e.get('available_from', None),
                    e.get('available_to', None),
                    available_from,
                    available_to,
                )
            ]

        return [sr.StorageRoom.from_dict(r) for r in result]
