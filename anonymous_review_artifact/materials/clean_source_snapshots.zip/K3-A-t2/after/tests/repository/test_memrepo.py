import pytest

from rentomatic.domain.storageroom import StorageRoom
from rentomatic.shared.domain_model import DomainModel

from rentomatic.repository import memrepo


@pytest.fixture
def storageroom_dicts():
    return [
        {
            'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
            'size': 215,
            'price': 39,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'featured': False,
        },
        {
            'code': 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
            'size': 405,
            'price': 66,
            'longitude': 0.18228006,
            'latitude': 51.74640997,
            'featured': True,
        },
        {
            'code': '913694c6-435a-4366-ba0d-da5334a611b2',
            'size': 56,
            'price': 60,
            'longitude': 0.27891577,
            'latitude': 51.45994069,
            'featured': False,
        },
        {
            'code': 'eed76e77-55c1-41ce-985d-ca49bf6c0585',
            'size': 93,
            'price': 48,
            'longitude': 0.33894476,
            'latitude': 51.39916678,
            'featured': False,
        },
        {
            'code': '2b8bbc4e-9f26-4e8d-a3cd-2a6d1c2f4e1a',
            'size': 120,
            'price': 82,
            'longitude': 0.44313203,
            'latitude': 51.23440137,
            'featured': True,
        }
    ]


@pytest.fixture
def storageroom_dicts_with_windows():
    rooms = [
        {
            'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
            'size': 215,
            'price': 39,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'featured': False,
            'available_from': '2026-11-01',
            'available_to': '2026-11-15',
        },
        {
            'code': 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
            'size': 405,
            'price': 66,
            'longitude': 0.18228006,
            'latitude': 51.74640997,
            'featured': True,
            'available_from': '2026-12-01',
            'available_to': '2026-12-20',
        },
        {
            'code': '913694c6-435a-4366-ba0d-da5334a611b2',
            'size': 56,
            'price': 60,
            'longitude': 0.27891577,
            'latitude': 51.45994069,
            'featured': False,
            'available_from': '2026-11-10',
            'available_to': '2026-12-05',
        },
        {
            'code': 'eed76e77-55c1-41ce-985d-ca49bf6c0585',
            'size': 93,
            'price': 48,
            'longitude': 0.33894476,
            'latitude': 51.39916678,
            'featured': False,
        },
    ]

    return rooms


def _check_results(domain_models_list, data_list):
    assert len(domain_models_list) == len(data_list)
    assert all([isinstance(dm, DomainModel) for dm in domain_models_list])
    assert set([dm.code for dm in domain_models_list]
               ) == set([d['code'] for d in data_list])


def test_repository_list_without_parameters(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(),
        storageroom_dicts
    )


def test_repository_list_with_filters_unknown_key(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    with pytest.raises(KeyError):
        repo.list(filters={'name': 'aname'})


def test_repository_list_with_filters_unknown_operator(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    with pytest.raises(ValueError):
        repo.list(filters={'price__in': [20, 30]})


def test_repository_list_with_filters_price(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'price': 60}),
        [storageroom_dicts[2]]
    )


def test_repository_list_with_filters_price_eq(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'price__eq': 60}),
        [storageroom_dicts[2]]
    )


def test_repository_list_with_filters_price_lt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'price__lt': 60}),
        [storageroom_dicts[0], storageroom_dicts[3]])


def test_repository_list_with_filters_price_gt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)
    _check_results(
        repo.list(filters={'price__gt': 60}),
        [storageroom_dicts[1], storageroom_dicts[4]]
    )


def test_repository_list_with_filters_size(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'size': 93}),
        [storageroom_dicts[3]]
    )


def test_repository_list_with_filters_size_eq(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)
    _check_results(
        repo.list(filters={'size__eq': 93}),
        [storageroom_dicts[3]]
    )


def test_repository_list_with_filters_size_lt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'size__lt': 60}),
        [storageroom_dicts[2]]
    )


def test_repository_list_with_filters_size_gt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)
    _check_results(
        repo.list(filters={'size__gt': 400}),
        [storageroom_dicts[1]]
    )


def test_repository_list_with_filters_code(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'code': '913694c6-435a-4366-ba0d-da5334a611b2'}),
        [storageroom_dicts[2]]
    )


def test_repository_list_with_filters_featured_true(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    result = repo.list(filters={'featured': True})

    _check_results(result, [storageroom_dicts[1], storageroom_dicts[4]])
    assert all([dm.featured is True for dm in result])


def test_repository_list_with_filters_featured_false(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    result = repo.list(filters={'featured': False})

    _check_results(
        result,
        [storageroom_dicts[0], storageroom_dicts[2], storageroom_dicts[3]]
    )
    assert all([dm.featured is False for dm in result])


def test_repository_list_with_filters_featured_string(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'featured': 'true'}),
        [storageroom_dicts[1], storageroom_dicts[4]]
    )


def test_repository_list_with_filters_featured_missing_key_defaults_false():
    repo = memrepo.MemRepo([
        {
            'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
            'size': 215,
            'price': 39,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
        },
        {
            'code': 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
            'size': 405,
            'price': 66,
            'longitude': 0.18228006,
            'latitude': 51.74640997,
            'featured': True,
        }
    ])

    result = repo.list(filters={'featured': False})

    _check_results(result, [repo._entries[0]])
    assert result[0].featured is False


def test_repository_list_returns_featured_attribute(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    result = repo.list()

    assert [dm.featured for dm in result] == \
        [d['featured'] for d in storageroom_dicts]


def test_repository_storageroom_default_featured_is_false():
    room = StorageRoom.from_dict({
        'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
        'size': 215,
        'price': 39,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
    })

    assert room.featured is False


def test_repository_list_without_availability_returns_rooms_with_and_without_windows(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    result = repo.list()

    _check_results(result, storageroom_dicts_with_windows)
    assert [dm.available_from for dm in result] == \
        [d.get('available_from', None) for d in storageroom_dicts_with_windows]


def test_repository_list_with_availability_window_returns_overlapping_rooms(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    _check_results(
        repo.list(available_from='2026-11-05', available_to='2026-11-20'),
        [storageroom_dicts_with_windows[0], storageroom_dicts_with_windows[2]]
    )


def test_repository_list_with_availability_window_is_inclusive_on_boundaries(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    # Single-day request matching the last day of the first room's window
    _check_results(
        repo.list(available_from='2026-11-15', available_to='2026-11-15'),
        [storageroom_dicts_with_windows[0], storageroom_dicts_with_windows[2]]
    )
    # Single-day request matching the first day of the second room's window
    _check_results(
        repo.list(available_from='2026-12-01', available_to='2026-12-01'),
        [storageroom_dicts_with_windows[1], storageroom_dicts_with_windows[2]]
    )


def test_repository_list_with_availability_window_without_match_returns_empty(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    assert repo.list(
        available_from='2027-01-01', available_to='2027-01-10') == []


def test_repository_list_with_one_sided_availability(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    # Rooms still available on or after 2026-11-20
    _check_results(
        repo.list(available_from='2026-11-20'),
        [storageroom_dicts_with_windows[1], storageroom_dicts_with_windows[2]]
    )
    # Rooms available on or before 2026-11-10
    _check_results(
        repo.list(available_to='2026-11-10'),
        [storageroom_dicts_with_windows[0], storageroom_dicts_with_windows[2]]
    )


def test_repository_list_with_availability_excludes_rooms_without_window(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    result = repo.list(
        available_from='2026-01-01', available_to='2026-12-31')

    _check_results(
        result,
        [storageroom_dicts_with_windows[0],
         storageroom_dicts_with_windows[1],
         storageroom_dicts_with_windows[2]]
    )
    assert all([dm.available_from is not None and dm.available_to is not None
                for dm in result])


def test_repository_list_with_availability_and_featured_filters(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    _check_results(
        repo.list(filters={'featured': True},
                  available_from='2026-11-25',
                  available_to='2026-12-10'),
        [storageroom_dicts_with_windows[1]]
    )

    # The featured room's window does not overlap the requested window
    assert repo.list(filters={'featured': True},
                     available_from='2026-11-05',
                     available_to='2026-11-20') == []
