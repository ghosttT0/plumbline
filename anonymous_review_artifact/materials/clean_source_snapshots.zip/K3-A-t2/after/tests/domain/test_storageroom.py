import datetime
import uuid

import pytest

from rentomatic.domain.storageroom import StorageRoom, parse_iso_date


def test_storageroom_model_init():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=10,
                              longitude=-0.09998975,
                              latitude=51.75436293)
    assert storageroom.code == code
    assert storageroom.size == 200
    assert storageroom.price == 10
    assert storageroom.longitude == -0.09998975
    assert storageroom.latitude == 51.75436293
    assert storageroom.featured is False
    assert storageroom.available_from is None
    assert storageroom.available_to is None


def test_storageroom_model_init_with_featured():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=10,
                              longitude=-0.09998975,
                              latitude=51.75436293,
                              featured=True)
    assert storageroom.code == code
    assert storageroom.size == 200
    assert storageroom.price == 10
    assert storageroom.longitude == -0.09998975
    assert storageroom.latitude == 51.75436293
    assert storageroom.featured is True
    assert storageroom.available_from is None
    assert storageroom.available_to is None


def test_storageroom_model_init_with_availability_window():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=10,
                              longitude=-0.09998975,
                              latitude=51.75436293,
                              available_from='2026-11-01',
                              available_to='2026-11-15')
    assert storageroom.available_from == '2026-11-01'
    assert storageroom.available_to == '2026-11-15'


def test_storageroom_model_from_dict():
    code = uuid.uuid4()
    storageroom = StorageRoom.from_dict(
        {
            'code': code,
            'size': 200,
            'price': 10,
            'longitude': -0.09998975,
            'latitude': 51.75436293
        }
    )
    assert storageroom.code == code
    assert storageroom.size == 200
    assert storageroom.price == 10
    assert storageroom.longitude == -0.09998975
    assert storageroom.latitude == 51.75436293
    assert storageroom.featured is False
    assert storageroom.available_from is None
    assert storageroom.available_to is None


def test_storageroom_model_from_dict_with_featured():
    code = uuid.uuid4()
    storageroom = StorageRoom.from_dict(
        {
            'code': code,
            'size': 200,
            'price': 10,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'featured': True
        }
    )
    assert storageroom.code == code
    assert storageroom.size == 200
    assert storageroom.price == 10
    assert storageroom.longitude == -0.09998975
    assert storageroom.latitude == 51.75436293
    assert storageroom.featured is True
    assert storageroom.available_from is None
    assert storageroom.available_to is None


def test_storageroom_model_from_dict_with_availability_window():
    code = uuid.uuid4()
    storageroom = StorageRoom.from_dict(
        {
            'code': code,
            'size': 200,
            'price': 10,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'available_from': '2026-11-01',
            'available_to': '2026-11-15'
        }
    )
    assert storageroom.available_from == '2026-11-01'
    assert storageroom.available_to == '2026-11-15'


def test_storageroom_model_to_dict():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': False
    }

    storageroom = StorageRoom.from_dict(storageroom_dict)

    assert storageroom.to_dict() == storageroom_dict


def test_storageroom_model_to_dict_with_featured():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': True
    }

    storageroom = StorageRoom.from_dict(storageroom_dict)

    assert storageroom.to_dict() == storageroom_dict


def test_storageroom_model_to_dict_with_availability_window():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': False,
        'available_from': '2026-11-01',
        'available_to': '2026-11-15'
    }

    storageroom = StorageRoom.from_dict(storageroom_dict)

    assert storageroom.to_dict() == storageroom_dict


def test_storageroom_model_to_dict_without_availability_omits_keys():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': False
    }

    room_dict = StorageRoom.from_dict(storageroom_dict).to_dict()

    assert 'available_from' not in room_dict
    assert 'available_to' not in room_dict


def test_storageroom_model_comparison():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': True
    }
    storageroom1 = StorageRoom.from_dict(storageroom_dict)
    storageroom2 = StorageRoom.from_dict(storageroom_dict)

    assert storageroom1 == storageroom2


def test_parse_iso_date_accepts_valid_iso_date():
    assert parse_iso_date('2026-11-01') == datetime.date(2026, 11, 1)


@pytest.mark.parametrize('value', [
    '2026-1-1',
    '01-11-2026',
    '2026/11/01',
    'not-a-date',
    '',
    '2026-02-30',
    5,
    None,
])
def test_parse_iso_date_rejects_malformed_dates(value):
    with pytest.raises(ValueError):
        parse_iso_date(value)


def test_window_overlaps_with_contained_requested_window():
    assert StorageRoom.window_overlaps(
        '2026-11-01', '2026-11-15', '2026-11-05', '2026-11-10') is True


def test_window_overlaps_with_containing_requested_window():
    assert StorageRoom.window_overlaps(
        '2026-11-05', '2026-11-10', '2026-11-01', '2026-11-15') is True


def test_window_overlaps_with_partially_overlapping_requested_window():
    assert StorageRoom.window_overlaps(
        '2026-11-05', '2026-11-10', '2026-11-08', '2026-11-20') is True
    assert StorageRoom.window_overlaps(
        '2026-11-05', '2026-11-10', '2026-10-20', '2026-11-07') is True


def test_window_overlaps_is_inclusive_on_boundaries():
    # The room's window ends exactly when the requested window starts
    assert StorageRoom.window_overlaps(
        '2026-11-01', '2026-11-15', '2026-11-15', '2026-11-20') is True
    # The room's window starts exactly when the requested window ends
    assert StorageRoom.window_overlaps(
        '2026-11-01', '2026-11-15', '2026-10-25', '2026-11-01') is True
    # Single-day request on a boundary of the room's window
    assert StorageRoom.window_overlaps(
        '2026-11-01', '2026-11-15', '2026-11-15', '2026-11-15') is True
    assert StorageRoom.window_overlaps(
        '2026-11-01', '2026-11-15', '2026-11-01', '2026-11-01') is True


def test_window_overlaps_with_disjoint_requested_window():
    assert StorageRoom.window_overlaps(
        '2026-11-01', '2026-11-15', '2026-11-16', '2026-11-20') is False
    assert StorageRoom.window_overlaps(
        '2026-11-01', '2026-11-15', '2026-10-01', '2026-10-31') is False


def test_window_overlaps_with_one_sided_requested_window():
    # Only a lower bound: the room must still be available on or after it
    assert StorageRoom.window_overlaps(
        '2026-11-01', '2026-11-15', '2026-11-15', None) is True
    assert StorageRoom.window_overlaps(
        '2026-11-01', '2026-11-15', '2026-11-16', None) is False
    # Only an upper bound: the room must already be available on or before it
    assert StorageRoom.window_overlaps(
        '2026-11-01', '2026-11-15', None, '2026-11-01') is True
    assert StorageRoom.window_overlaps(
        '2026-11-01', '2026-11-15', None, '2026-10-31') is False


def test_window_overlaps_room_without_window_never_matches():
    assert StorageRoom.window_overlaps(
        None, '2026-11-15', '2026-11-01', '2026-11-30') is False
    assert StorageRoom.window_overlaps(
        '2026-11-01', None, '2026-11-01', '2026-11-30') is False
    assert StorageRoom.window_overlaps(
        None, None, '2026-11-01', '2026-11-30') is False


@pytest.mark.parametrize('room_from,room_to,requested_from,requested_to', [
    ('2026-11-1', '2026-11-15', '2026-11-01', '2026-11-30'),
    ('2026-11-01', '20261115', '2026-11-01', '2026-11-30'),
    ('2026-11-01', '2026-11-15', '01-11-2026', '2026-11-30'),
    ('2026-11-01', '2026-11-15', '2026-11-01', '2026-13-40'),
])
def test_window_overlaps_rejects_malformed_dates(
        room_from, room_to, requested_from, requested_to):
    with pytest.raises(ValueError):
        StorageRoom.window_overlaps(
            room_from, room_to, requested_from, requested_to)
