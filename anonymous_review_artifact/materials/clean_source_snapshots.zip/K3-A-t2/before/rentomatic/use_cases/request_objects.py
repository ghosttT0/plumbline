import collections.abc

from rentomatic.shared import request_object as req


class StorageRoomListRequestObject(req.ValidRequestObject):

    def __init__(self, filters=None, featured=None):
        self.filters = filters
        self.featured = featured

    @staticmethod
    def _parse_bool(value):
        if isinstance(value, bool):
            return value

        if isinstance(value, str):
            normalised = value.strip().lower()
            if normalised == 'true':
                return True
            if normalised == 'false':
                return False

        return None

    @classmethod
    def from_dict(cls, adict):
        invalid_req = req.InvalidRequestObject()

        if 'filters' in adict and not isinstance(adict['filters'], collections.abc.Mapping):
            invalid_req.add_error('filters', 'Is not iterable')

        featured = None
        if adict.get('featured', None) is not None:
            featured = cls._parse_bool(adict['featured'])
            if featured is None:
                invalid_req.add_error('featured', 'Must be true or false')

        if invalid_req.has_errors():
            return invalid_req

        return StorageRoomListRequestObject(
            filters=adict.get('filters', None),
            featured=featured,
        )
