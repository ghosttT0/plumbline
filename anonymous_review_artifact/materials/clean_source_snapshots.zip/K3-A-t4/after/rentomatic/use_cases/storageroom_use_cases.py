from rentomatic.shared import use_case as uc
from rentomatic.shared import response_object as res


class StorageRoomListUseCase(uc.UseCase):

    def __init__(self, repo):
        self.repo = repo

    def process_request(self, request_object):
        filters = request_object.filters

        if request_object.featured is not None:
            filters = dict(filters) if filters else {}
            filters['featured'] = request_object.featured

        domain_storagerooms = self.repo.list(
            filters=filters,
            available_from=request_object.available_from,
            available_to=request_object.available_to,
            sort=request_object.sort,
        )

        page = request_object.page
        per_page = request_object.per_page
        start = (page - 1) * per_page
        end = start + per_page

        return res.ResponseSuccess({
            'results': domain_storagerooms[start:end],
            'page': page,
            'per_page': per_page,
            'total': len(domain_storagerooms),
        })
