import collections.abc

from rentomatic.domain.storageroom import parse_iso_date
from rentomatic.shared import request_object as req


class StorageRoomListRequestObject(req.ValidRequestObject):

    SORT_CHOICES = ('price_asc', 'price_desc')

    DEFAULT_PAGE = 1
    DEFAULT_PER_PAGE = 100
    MIN_PAGE = 1
    MIN_PER_PAGE = 1
    MAX_PER_PAGE = 100

    def __init__(self, filters=None, featured=None,
                 available_from=None, available_to=None, sort=None,
                 page=None, per_page=None):
        self.filters = filters
        self.featured = featured
        self.available_from = available_from
        self.available_to = available_to
        self.sort = sort
        self.page = self.DEFAULT_PAGE if page is None else page
        self.per_page = \
            self.DEFAULT_PER_PAGE if per_page is None else per_page

    @staticmethod
    def _parse_bool(value):
        if isinstance(value, bool):
            return value

        if isinstance(value, str):
            normalised = value.strip().lower()
            if normalised == 'true':
                return True
            if normalised == 'false':
                return False

        return None

    @staticmethod
    def _parse_int(value):
        """Return ``value`` as an ``int``, or ``None`` when it is not an
        integer.

        Integers and strings containing an integer are accepted; booleans
        and any other type are rejected.
        """
        if isinstance(value, bool):
            return None

        if isinstance(value, int):
            return value

        if isinstance(value, str):
            try:
                return int(value.strip())
            except ValueError:
                return None

        return None

    @staticmethod
    def _is_iso_date(value):
        try:
            parse_iso_date(value)
        except ValueError:
            return False

        return True

    @classmethod
    def from_dict(cls, adict):
        invalid_req = req.InvalidRequestObject()

        if 'filters' in adict and not isinstance(adict['filters'], collections.abc.Mapping):
            invalid_req.add_error('filters', 'Is not iterable')

        featured = None
        if adict.get('featured', None) is not None:
            featured = cls._parse_bool(adict['featured'])
            if featured is None:
                invalid_req.add_error('featured', 'Must be true or false')

        for parameter in ['available_from', 'available_to']:
            value = adict.get(parameter, None)
            if value is not None and not cls._is_iso_date(value):
                invalid_req.add_error(
                    parameter, 'Must be a date in YYYY-MM-DD format')

        sort = adict.get('sort', None)
        if sort is not None and sort not in cls.SORT_CHOICES:
            invalid_req.add_error(
                'sort', 'Must be one of: ' + ', '.join(cls.SORT_CHOICES))

        page = cls.DEFAULT_PAGE
        raw_page = adict.get('page', None)
        if raw_page is not None:
            page = cls._parse_int(raw_page)
            if page is None:
                invalid_req.add_error('page', 'Must be an integer')
            elif page < cls.MIN_PAGE:
                invalid_req.add_error(
                    'page',
                    'Must be greater than or equal to {}'.format(
                        cls.MIN_PAGE))

        per_page = cls.DEFAULT_PER_PAGE
        raw_per_page = adict.get('per_page', None)
        if raw_per_page is not None:
            per_page = cls._parse_int(raw_per_page)
            if per_page is None:
                invalid_req.add_error('per_page', 'Must be an integer')
            elif not cls.MIN_PER_PAGE <= per_page <= cls.MAX_PER_PAGE:
                invalid_req.add_error(
                    'per_page',
                    'Must be between {} and {}'.format(
                        cls.MIN_PER_PAGE, cls.MAX_PER_PAGE))

        if invalid_req.has_errors():
            return invalid_req

        return StorageRoomListRequestObject(
            filters=adict.get('filters', None),
            featured=featured,
            available_from=adict.get('available_from', None),
            available_to=adict.get('available_to', None),
            sort=sort,
            page=page,
            per_page=per_page,
        )
