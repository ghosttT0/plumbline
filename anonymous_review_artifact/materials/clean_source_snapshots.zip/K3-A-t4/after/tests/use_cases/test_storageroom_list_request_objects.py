import collections.abc

from rentomatic.use_cases import request_objects as ro


def test_build_storageroom_list_request_object_without_parameters():
    req = ro.StorageRoomListRequestObject()

    assert req.filters is None
    assert req.featured is None
    assert bool(req) is True


def test_build_file_list_request_object_from_empty_dict():
    req = ro.StorageRoomListRequestObject.from_dict({})

    assert req.filters is None
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_empty_filters():
    req = ro.StorageRoomListRequestObject(filters={})

    assert req.filters == {}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_empty_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': {}})

    assert req.filters == {}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_filters():
    req = ro.StorageRoomListRequestObject(filters={'a': 1, 'b': 2})

    assert req.filters == {'a': 1, 'b': 2}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': {'a': 1, 'b': 2}})

    assert req.filters == {'a': 1, 'b': 2}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': 5})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'filters'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_featured_true():
    req = ro.StorageRoomListRequestObject(featured=True)

    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_featured_false():
    req = ro.StorageRoomListRequestObject(featured=False)

    assert req.featured is False
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_featured_true():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': 'true'})

    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_featured_false():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': 'false'})

    assert req.featured is False
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_featured_boolean():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': True})

    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_featured_and_filters():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 10}, 'featured': 'true'})

    assert req.filters == {'price__lt': 10}
    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_featured():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': 'maybe'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'featured'
    assert req.errors[0]['message'] == 'Must be true or false'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_availability_window():
    req = ro.StorageRoomListRequestObject(
        available_from='2026-11-01', available_to='2026-11-15')

    assert req.available_from == '2026-11-01'
    assert req.available_to == '2026-11-15'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_availability_window():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01', 'available_to': '2026-11-15'})

    assert req.available_from == '2026-11-01'
    assert req.available_to == '2026-11-15'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_availability_and_filters():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 10},
         'available_from': '2026-11-01',
         'available_to': '2026-11-15'})

    assert req.filters == {'price__lt': 10}
    assert req.available_from == '2026-11-01'
    assert req.available_to == '2026-11-15'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_malformed_available_from():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '01-11-2026'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert req.errors[0]['message'] == 'Must be a date in YYYY-MM-DD format'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_malformed_available_to():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_to': '2026-02-30'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_to'
    assert req.errors[0]['message'] == 'Must be a date in YYYY-MM-DD format'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_malformed_availability_window():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': 'not-a-date', 'available_to': '2026/11/15'})

    assert req.has_errors()
    assert [e['parameter'] for e in req.errors] == \
        ['available_from', 'available_to']
    assert all([e['message'] == 'Must be a date in YYYY-MM-DD format'
                for e in req.errors])
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_string_availability():
    req = ro.StorageRoomListRequestObject.from_dict({'available_from': 5})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert req.errors[0]['message'] == 'Must be a date in YYYY-MM-DD format'
    assert bool(req) is False


def test_build_storageroom_list_request_object_without_sort():
    req = ro.StorageRoomListRequestObject()

    assert req.sort is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_empty_dict_has_no_sort():
    req = ro.StorageRoomListRequestObject.from_dict({})

    assert req.sort is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_sort_price_asc():
    req = ro.StorageRoomListRequestObject(sort='price_asc')

    assert req.sort == 'price_asc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_sort_price_desc():
    req = ro.StorageRoomListRequestObject(sort='price_desc')

    assert req.sort == 'price_desc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_sort_price_asc():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'price_asc'})

    assert req.sort == 'price_asc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_sort_price_desc():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'price_desc'})

    assert req.sort == 'price_desc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_sort():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'price'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'sort'
    assert req.errors[0]['message'] == 'Must be one of: price_asc, price_desc'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_string_sort():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 5})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'sort'
    assert req.errors[0]['message'] == 'Must be one of: price_asc, price_desc'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_sort_and_filters():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 10}, 'sort': 'price_desc'})

    assert req.filters == {'price__lt': 10}
    assert req.sort == 'price_desc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_has_default_pagination():
    req = ro.StorageRoomListRequestObject()

    assert req.page == 1
    assert req.per_page == 100
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_empty_dict_has_default_pagination():
    req = ro.StorageRoomListRequestObject.from_dict({})

    assert req.page == 1
    assert req.per_page == 100
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_pagination():
    req = ro.StorageRoomListRequestObject(page=3, per_page=25)

    assert req.page == 3
    assert req.per_page == 25
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_pagination():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'page': '3', 'per_page': '25'})

    assert req.page == 3
    assert req.per_page == 25
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_integer_pagination():
    req = ro.StorageRoomListRequestObject.from_dict({'page': 2, 'per_page': 50})

    assert req.page == 2
    assert req.per_page == 50
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_pagination_lower_boundaries():
    req = ro.StorageRoomListRequestObject.from_dict({'page': 1, 'per_page': 1})

    assert req.page == 1
    assert req.per_page == 1
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_pagination_upper_boundaries():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'page': 42, 'per_page': 100})

    assert req.page == 42
    assert req.per_page == 100
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_pagination_and_other_parameters():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 10},
         'featured': 'true',
         'available_from': '2026-11-01',
         'sort': 'price_asc',
         'page': '2',
         'per_page': '10'})

    assert req.filters == {'price__lt': 10}
    assert req.featured is True
    assert req.available_from == '2026-11-01'
    assert req.sort == 'price_asc'
    assert req.page == 2
    assert req.per_page == 10
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_page_zero():
    req = ro.StorageRoomListRequestObject.from_dict({'page': 0})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'page'
    assert req.errors[0]['message'] == 'Must be greater than or equal to 1'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_negative_page():
    req = ro.StorageRoomListRequestObject.from_dict({'page': -3})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'page'
    assert req.errors[0]['message'] == 'Must be greater than or equal to 1'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_negative_string_page():
    req = ro.StorageRoomListRequestObject.from_dict({'page': '-3'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'page'
    assert req.errors[0]['message'] == 'Must be greater than or equal to 1'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_integer_page():
    req = ro.StorageRoomListRequestObject.from_dict({'page': 'two'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'page'
    assert req.errors[0]['message'] == 'Must be an integer'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_decimal_page():
    req = ro.StorageRoomListRequestObject.from_dict({'page': '1.5'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'page'
    assert req.errors[0]['message'] == 'Must be an integer'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_boolean_page():
    req = ro.StorageRoomListRequestObject.from_dict({'page': True})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'page'
    assert req.errors[0]['message'] == 'Must be an integer'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_per_page_zero():
    req = ro.StorageRoomListRequestObject.from_dict({'per_page': 0})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'per_page'
    assert req.errors[0]['message'] == 'Must be between 1 and 100'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_negative_per_page():
    req = ro.StorageRoomListRequestObject.from_dict({'per_page': -5})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'per_page'
    assert req.errors[0]['message'] == 'Must be between 1 and 100'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_per_page_above_maximum():
    req = ro.StorageRoomListRequestObject.from_dict({'per_page': 101})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'per_page'
    assert req.errors[0]['message'] == 'Must be between 1 and 100'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_per_page_above_maximum_as_string():
    req = ro.StorageRoomListRequestObject.from_dict({'per_page': '1000'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'per_page'
    assert req.errors[0]['message'] == 'Must be between 1 and 100'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_integer_per_page():
    req = ro.StorageRoomListRequestObject.from_dict({'per_page': 'many'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'per_page'
    assert req.errors[0]['message'] == 'Must be an integer'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_boolean_per_page():
    req = ro.StorageRoomListRequestObject.from_dict({'per_page': False})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'per_page'
    assert req.errors[0]['message'] == 'Must be an integer'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_invalid_page_and_per_page():
    req = ro.StorageRoomListRequestObject.from_dict({'page': 0, 'per_page': 0})

    assert req.has_errors()
    assert [e['parameter'] for e in req.errors] == ['page', 'per_page']
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_invalid_page_keeps_other_errors():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'page': 0, 'featured': 'maybe'})

    assert req.has_errors()
    assert [e['parameter'] for e in req.errors] == ['featured', 'page']
    assert bool(req) is False
