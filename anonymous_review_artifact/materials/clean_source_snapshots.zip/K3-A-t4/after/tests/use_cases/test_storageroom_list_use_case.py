import uuid

import pytest
from unittest import mock

from rentomatic.domain.storageroom import StorageRoom
from rentomatic.shared import response_object as res
from rentomatic.use_cases import request_objects as req
from rentomatic.use_cases import storageroom_use_cases as uc


@pytest.fixture
def domain_storagerooms():
    storageroom_1 = StorageRoom(
        code=uuid.uuid4(),
        size=215,
        price=39,
        longitude=-0.09998975,
        latitude=51.75436293,
        featured=False,
    )

    storageroom_2 = StorageRoom(
        code=uuid.uuid4(),
        size=405,
        price=66,
        longitude=0.18228006,
        latitude=51.74640997,
        featured=True,
    )

    storageroom_3 = StorageRoom(
        code=uuid.uuid4(),
        size=56,
        price=60,
        longitude=0.27891577,
        latitude=51.45994069,
        featured=False,
    )

    storageroom_4 = StorageRoom(
        code=uuid.uuid4(),
        size=93,
        price=48,
        longitude=0.33894476,
        latitude=51.39916678,
        featured=True,
    )

    return [storageroom_1, storageroom_2, storageroom_3, storageroom_4]


def _envelope(results, page=1, per_page=100, total=None):
    return {
        'results': results,
        'page': page,
        'per_page': per_page,
        'total': len(results) if total is None else total,
    }


def test_storageroom_list_without_parameters(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters=None, available_from=None, available_to=None, sort=None)

    assert response_object.value == \
        _envelope(domain_storagerooms, total=4)


def test_storageroom_list_with_filters(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    qry_filters = {'a': 5}
    request_object = req.StorageRoomListRequestObject.from_dict({'filters': qry_filters})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters=qry_filters, available_from=None, available_to=None,
        sort=None)
    assert response_object.value == \
        _envelope(domain_storagerooms, total=4)


def test_storageroom_list_with_featured_true(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({'featured': 'true'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'featured': True}, available_from=None, available_to=None,
        sort=None)
    assert response_object.value == \
        _envelope(domain_storagerooms, total=4)


def test_storageroom_list_with_featured_false(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({'featured': 'false'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'featured': False}, available_from=None, available_to=None,
        sort=None)
    assert response_object.value == \
        _envelope(domain_storagerooms, total=4)


def test_storageroom_list_with_featured_and_filters(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 10}, 'featured': True})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'price__lt': 10, 'featured': True},
        available_from=None,
        available_to=None,
        sort=None)
    assert response_object.value == \
        _envelope(domain_storagerooms, total=4)


def test_storageroom_list_with_availability_window(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01', 'available_to': '2026-11-15'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters=None,
        available_from='2026-11-01',
        available_to='2026-11-15',
        sort=None)
    assert response_object.value == \
        _envelope(domain_storagerooms, total=4)


def test_storageroom_list_with_availability_window_and_filters(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 10}, 'available_from': '2026-11-01'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'price__lt': 10},
        available_from='2026-11-01',
        available_to=None,
        sort=None)
    assert response_object.value == \
        _envelope(domain_storagerooms, total=4)


def test_storageroom_list_with_sort_price_asc(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'sort': 'price_asc'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters=None, available_from=None, available_to=None,
        sort='price_asc')
    assert response_object.value == \
        _envelope(domain_storagerooms, total=4)


def test_storageroom_list_with_sort_price_desc(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'sort': 'price_desc'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters=None, available_from=None, available_to=None,
        sort='price_desc')
    assert response_object.value == \
        _envelope(domain_storagerooms, total=4)


def test_storageroom_list_with_sort_and_filters(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 70}, 'sort': 'price_desc'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'price__lt': 70},
        available_from=None,
        available_to=None,
        sort='price_desc')
    assert response_object.value == \
        _envelope(domain_storagerooms, total=4)


def test_storageroom_list_with_pagination_returns_requested_page(
        domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'page': '2', 'per_page': '2'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters=None, available_from=None, available_to=None, sort=None)
    assert response_object.value == {
        'results': domain_storagerooms[2:4],
        'page': 2,
        'per_page': 2,
        'total': 4,
    }


def test_storageroom_list_with_pagination_returns_first_page(
        domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'page': '1', 'per_page': '2'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert response_object.value == {
        'results': domain_storagerooms[0:2],
        'page': 1,
        'per_page': 2,
        'total': 4,
    }


def test_storageroom_list_with_pagination_returns_last_partial_page(
        domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'page': '2', 'per_page': '3'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert response_object.value == {
        'results': domain_storagerooms[3:4],
        'page': 2,
        'per_page': 3,
        'total': 4,
    }


def test_storageroom_list_with_pagination_beyond_last_page_returns_empty_results(
        domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'page': '3', 'per_page': '2'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert response_object.value == {
        'results': [],
        'page': 3,
        'per_page': 2,
        'total': 4,
    }


def test_storageroom_list_with_pagination_over_empty_result_set():
    repo = mock.Mock()
    repo.list.return_value = []

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'page': '1', 'per_page': '10'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    assert response_object.value == {
        'results': [],
        'page': 1,
        'per_page': 10,
        'total': 0,
    }


def test_storageroom_list_applies_filters_before_paging(domain_storagerooms):
    # The repository returns the filtered subset; the use case pages
    # over that subset, and the total refers to it as well
    repo = mock.Mock()
    filtered = domain_storagerooms[1::2]
    repo.list.return_value = filtered

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'featured': 'true', 'page': '2', 'per_page': '1'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'featured': True}, available_from=None, available_to=None,
        sort=None)
    assert response_object.value == {
        'results': filtered[1:2],
        'page': 2,
        'per_page': 1,
        'total': 2,
    }


def test_storageroom_list_handles_generic_error():
    repo = mock.Mock()
    repo.list.side_effect = Exception('Just an error message')

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    assert response_object.value == {
        'type': res.ResponseFailure.SYSTEM_ERROR,
        'message': "Exception: Just an error message"
    }


def test_storageroom_list_handles_bad_request():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({'filters': 5})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': "filters: Is not iterable"
    }


def test_storageroom_list_handles_bad_featured_request():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({'featured': 'maybe'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    repo.list.assert_not_called()
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': "featured: Must be true or false"
    }


def test_storageroom_list_handles_bad_availability_request():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'available_from': 'not-a-date'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    repo.list.assert_not_called()
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': "available_from: Must be a date in YYYY-MM-DD format"
    }


def test_storageroom_list_handles_bad_sort_request():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'sort': 'price'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    repo.list.assert_not_called()
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': "sort: Must be one of: price_asc, price_desc"
    }


def test_storageroom_list_handles_bad_page_request():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({'page': 0})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    repo.list.assert_not_called()
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': "page: Must be greater than or equal to 1"
    }


def test_storageroom_list_handles_non_integer_page_request():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'page': 'two'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    repo.list.assert_not_called()
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': "page: Must be an integer"
    }


def test_storageroom_list_handles_bad_per_page_request():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'per_page': 101})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    repo.list.assert_not_called()
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': "per_page: Must be between 1 and 100"
    }


def test_storageroom_list_handles_non_integer_per_page_request():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'per_page': 'many'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    repo.list.assert_not_called()
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': "per_page: Must be an integer"
    }
