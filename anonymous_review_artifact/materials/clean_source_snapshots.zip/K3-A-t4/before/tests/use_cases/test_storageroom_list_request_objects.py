import collections.abc

from rentomatic.use_cases import request_objects as ro


def test_build_storageroom_list_request_object_without_parameters():
    req = ro.StorageRoomListRequestObject()

    assert req.filters is None
    assert req.featured is None
    assert bool(req) is True


def test_build_file_list_request_object_from_empty_dict():
    req = ro.StorageRoomListRequestObject.from_dict({})

    assert req.filters is None
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_empty_filters():
    req = ro.StorageRoomListRequestObject(filters={})

    assert req.filters == {}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_empty_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': {}})

    assert req.filters == {}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_filters():
    req = ro.StorageRoomListRequestObject(filters={'a': 1, 'b': 2})

    assert req.filters == {'a': 1, 'b': 2}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': {'a': 1, 'b': 2}})

    assert req.filters == {'a': 1, 'b': 2}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': 5})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'filters'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_featured_true():
    req = ro.StorageRoomListRequestObject(featured=True)

    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_featured_false():
    req = ro.StorageRoomListRequestObject(featured=False)

    assert req.featured is False
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_featured_true():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': 'true'})

    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_featured_false():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': 'false'})

    assert req.featured is False
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_featured_boolean():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': True})

    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_featured_and_filters():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 10}, 'featured': 'true'})

    assert req.filters == {'price__lt': 10}
    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_featured():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': 'maybe'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'featured'
    assert req.errors[0]['message'] == 'Must be true or false'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_availability_window():
    req = ro.StorageRoomListRequestObject(
        available_from='2026-11-01', available_to='2026-11-15')

    assert req.available_from == '2026-11-01'
    assert req.available_to == '2026-11-15'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_availability_window():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01', 'available_to': '2026-11-15'})

    assert req.available_from == '2026-11-01'
    assert req.available_to == '2026-11-15'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_availability_and_filters():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 10},
         'available_from': '2026-11-01',
         'available_to': '2026-11-15'})

    assert req.filters == {'price__lt': 10}
    assert req.available_from == '2026-11-01'
    assert req.available_to == '2026-11-15'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_malformed_available_from():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '01-11-2026'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert req.errors[0]['message'] == 'Must be a date in YYYY-MM-DD format'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_malformed_available_to():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_to': '2026-02-30'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_to'
    assert req.errors[0]['message'] == 'Must be a date in YYYY-MM-DD format'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_malformed_availability_window():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': 'not-a-date', 'available_to': '2026/11/15'})

    assert req.has_errors()
    assert [e['parameter'] for e in req.errors] == \
        ['available_from', 'available_to']
    assert all([e['message'] == 'Must be a date in YYYY-MM-DD format'
                for e in req.errors])
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_string_availability():
    req = ro.StorageRoomListRequestObject.from_dict({'available_from': 5})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert req.errors[0]['message'] == 'Must be a date in YYYY-MM-DD format'
    assert bool(req) is False


def test_build_storageroom_list_request_object_without_sort():
    req = ro.StorageRoomListRequestObject()

    assert req.sort is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_empty_dict_has_no_sort():
    req = ro.StorageRoomListRequestObject.from_dict({})

    assert req.sort is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_sort_price_asc():
    req = ro.StorageRoomListRequestObject(sort='price_asc')

    assert req.sort == 'price_asc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_sort_price_desc():
    req = ro.StorageRoomListRequestObject(sort='price_desc')

    assert req.sort == 'price_desc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_sort_price_asc():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'price_asc'})

    assert req.sort == 'price_asc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_sort_price_desc():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'price_desc'})

    assert req.sort == 'price_desc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_sort():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'price'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'sort'
    assert req.errors[0]['message'] == 'Must be one of: price_asc, price_desc'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_string_sort():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 5})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'sort'
    assert req.errors[0]['message'] == 'Must be one of: price_asc, price_desc'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_sort_and_filters():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 10}, 'sort': 'price_desc'})

    assert req.filters == {'price__lt': 10}
    assert req.sort == 'price_desc'
    assert bool(req) is True
