import json
from unittest import mock

from rentomatic.domain.storageroom import StorageRoom
from rentomatic.shared import response_object as res

storageroom1_dict = {
    'code': '3251a5bd-86be-428d-8ae9-6e51a8048c33',
    'size': 200,
    'price': 10,
    'longitude': -0.09998975,
    'latitude': 51.75436293,
    'featured': False
}

storageroom1_domain_model = StorageRoom.from_dict(storageroom1_dict)

storagerooms = [storageroom1_domain_model]


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_get(mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess(storagerooms)

    http_response = client.get('/storagerooms')

    assert json.loads(http_response.data.decode(
        'UTF-8')) == [storageroom1_dict]
    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_get_failed_response(mock_use_case, client):
    mock_use_case().execute.return_value = \
        res.ResponseFailure.build_system_error('test message')

    http_response = client.get('/storagerooms')

    assert json.loads(http_response.data.decode('UTF-8')) == \
        {'type': 'SYSTEM_ERROR', 'message': 'test message'}
    assert http_response.status_code == 500
    assert http_response.mimetype == 'application/json'


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_filters(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?filter_param1=value1&filter_param2=value2')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {'param1': 'value1', 'param2': 'value2'}}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_featured(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?featured=true')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'featured': 'true'}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_availability_window(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get(
            '/storagerooms?available_from=2026-11-01&available_to=2026-11-15')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {},
         'available_from': '2026-11-01',
         'available_to': '2026-11-15'}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_sort(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?sort=price_desc')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'sort': 'price_desc'}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


def test_get_without_parameters_returns_all_seed_rooms(client):
    http_response = client.get('/storagerooms')

    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'

    rooms = json.loads(http_response.data.decode('UTF-8'))
    assert len(rooms) == 5
    assert len([r for r in rooms if r['featured'] is True]) == 2
    assert len([r for r in rooms if r['featured'] is False]) == 3


def test_get_returns_availability_window_of_advertising_rooms(client):
    http_response = client.get('/storagerooms')

    assert http_response.status_code == 200

    rooms = json.loads(http_response.data.decode('UTF-8'))
    windows = {r['code']: (r.get('available_from'), r.get('available_to'))
               for r in rooms}

    assert windows['f853578c-fc0f-4e65-81b8-566c5dffa35a'] == \
        ('2026-11-01', '2026-11-15')
    assert windows['fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a'] == \
        ('2026-12-01', '2026-12-20')
    assert windows['2b8bbc4e-9f26-4e8d-a3cd-2a6d1c2f4e1a'] == \
        ('2026-11-10', '2026-12-05')
    assert 'available_from' not in [
        r for r in rooms
        if r['code'] == '913694c6-435a-4366-ba0d-da5334a611b2'][0]
    assert 'available_to' not in [
        r for r in rooms
        if r['code'] == 'eed76e77-55c1-41ce-985d-ca49bf6c0585'][0]


def test_get_with_featured_true_returns_only_featured_rooms(client):
    http_response = client.get('/storagerooms?featured=true')

    assert http_response.status_code == 200

    rooms = json.loads(http_response.data.decode('UTF-8'))
    assert len(rooms) == 2
    assert all([r['featured'] is True for r in rooms])


def test_get_with_featured_false_returns_only_non_featured_rooms(client):
    http_response = client.get('/storagerooms?featured=false')

    assert http_response.status_code == 200

    rooms = json.loads(http_response.data.decode('UTF-8'))
    assert len(rooms) == 3
    assert all([r['featured'] is False for r in rooms])


def test_get_with_invalid_featured_value_returns_400(client):
    http_response = client.get('/storagerooms?featured=maybe')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'featured: Must be true or false'
    }


def test_get_with_availability_window_returns_overlapping_rooms(client):
    http_response = client.get(
        '/storagerooms?available_from=2026-11-05&available_to=2026-11-20')

    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'

    rooms = json.loads(http_response.data.decode('UTF-8'))

    # Rooms 1 (2026-11-01..2026-11-15) and 5 (2026-11-10..2026-12-05)
    # overlap the requested window
    assert len(rooms) == 2
    assert set([r['code'] for r in rooms]) == {
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',
        '2b8bbc4e-9f26-4e8d-a3cd-2a6d1c2f4e1a',
    }


def test_get_with_availability_window_matching_on_a_boundary_is_inclusive(
        client):
    # 2026-11-15 is the last day of room 1's window
    http_response = client.get(
        '/storagerooms?available_from=2026-11-15&available_to=2026-11-15')

    assert http_response.status_code == 200

    rooms = json.loads(http_response.data.decode('UTF-8'))
    assert set([r['code'] for r in rooms]) == {
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',
        '2b8bbc4e-9f26-4e8d-a3cd-2a6d1c2f4e1a',
    }


def test_get_with_availability_window_without_overlap_returns_no_rooms(client):
    http_response = client.get(
        '/storagerooms?available_from=2027-01-01&available_to=2027-01-10')

    assert http_response.status_code == 200
    assert json.loads(http_response.data.decode('UTF-8')) == []


def test_get_with_one_sided_availability_window(client):
    http_response = client.get('/storagerooms?available_from=2026-11-20')

    assert http_response.status_code == 200

    rooms = json.loads(http_response.data.decode('UTF-8'))
    assert set([r['code'] for r in rooms]) == {
        'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
        '2b8bbc4e-9f26-4e8d-a3cd-2a6d1c2f4e1a',
    }


def test_get_with_malformed_available_from_returns_400(client):
    http_response = client.get('/storagerooms?available_from=01-11-2026')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_from: Must be a date in YYYY-MM-DD format'
    }


def test_get_with_malformed_available_to_returns_400(client):
    http_response = client.get('/storagerooms?available_to=2026-13-40')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_to: Must be a date in YYYY-MM-DD format'
    }


def test_get_without_sort_keeps_seed_order(client):
    http_response = client.get('/storagerooms')

    assert http_response.status_code == 200

    rooms = json.loads(http_response.data.decode('UTF-8'))

    # Seed order: prices 39, 66, 60, 48, 82
    assert [r['price'] for r in rooms] == [39, 66, 60, 48, 82]


def test_get_with_sort_price_asc_returns_rooms_ordered_by_price(client):
    http_response = client.get('/storagerooms?sort=price_asc')

    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'

    rooms = json.loads(http_response.data.decode('UTF-8'))

    assert [r['price'] for r in rooms] == [39, 48, 60, 66, 82]
    assert [r['code'] for r in rooms] == [
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',
        'eed76e77-55c1-41ce-985d-ca49bf6c0585',
        '913694c6-435a-4366-ba0d-da5334a611b2',
        'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
        '2b8bbc4e-9f26-4e8d-a3cd-2a6d1c2f4e1a',
    ]


def test_get_with_sort_price_desc_returns_rooms_ordered_by_price(client):
    http_response = client.get('/storagerooms?sort=price_desc')

    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'

    rooms = json.loads(http_response.data.decode('UTF-8'))

    assert [r['price'] for r in rooms] == [82, 66, 60, 48, 39]
    assert [r['code'] for r in rooms] == [
        '2b8bbc4e-9f26-4e8d-a3cd-2a6d1c2f4e1a',
        'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
        '913694c6-435a-4366-ba0d-da5334a611b2',
        'eed76e77-55c1-41ce-985d-ca49bf6c0585',
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',
    ]


def test_get_with_sort_and_featured_returns_filtered_sorted_rooms(client):
    http_response = client.get(
        '/storagerooms?featured=true&sort=price_desc')

    assert http_response.status_code == 200

    rooms = json.loads(http_response.data.decode('UTF-8'))

    # Only the two featured rooms (prices 48 and 82), descending
    assert [r['price'] for r in rooms] == [82, 48]
    assert all([r['featured'] is True for r in rooms])


def test_get_with_unknown_sort_value_returns_400(client):
    http_response = client.get('/storagerooms?sort=size_asc')

    assert http_response.status_code == 400
    assert http_response.mimetype == 'application/json'
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'sort: Must be one of: price_asc, price_desc'
    }
