import collections.abc

from rentomatic.domain.storageroom import parse_iso_date
from rentomatic.shared import request_object as req


class StorageRoomListRequestObject(req.ValidRequestObject):

    SORT_CHOICES = ('price_asc', 'price_desc')

    def __init__(self, filters=None, featured=None,
                 available_from=None, available_to=None, sort=None):
        self.filters = filters
        self.featured = featured
        self.available_from = available_from
        self.available_to = available_to
        self.sort = sort

    @staticmethod
    def _parse_bool(value):
        if isinstance(value, bool):
            return value

        if isinstance(value, str):
            normalised = value.strip().lower()
            if normalised == 'true':
                return True
            if normalised == 'false':
                return False

        return None

    @staticmethod
    def _is_iso_date(value):
        try:
            parse_iso_date(value)
        except ValueError:
            return False

        return True

    @classmethod
    def from_dict(cls, adict):
        invalid_req = req.InvalidRequestObject()

        if 'filters' in adict and not isinstance(adict['filters'], collections.abc.Mapping):
            invalid_req.add_error('filters', 'Is not iterable')

        featured = None
        if adict.get('featured', None) is not None:
            featured = cls._parse_bool(adict['featured'])
            if featured is None:
                invalid_req.add_error('featured', 'Must be true or false')

        for parameter in ['available_from', 'available_to']:
            value = adict.get(parameter, None)
            if value is not None and not cls._is_iso_date(value):
                invalid_req.add_error(
                    parameter, 'Must be a date in YYYY-MM-DD format')

        sort = adict.get('sort', None)
        if sort is not None and sort not in cls.SORT_CHOICES:
            invalid_req.add_error(
                'sort', 'Must be one of: ' + ', '.join(cls.SORT_CHOICES))

        if invalid_req.has_errors():
            return invalid_req

        return StorageRoomListRequestObject(
            filters=adict.get('filters', None),
            featured=featured,
            available_from=adict.get('available_from', None),
            available_to=adict.get('available_to', None),
            sort=sort,
        )
