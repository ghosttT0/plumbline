import datetime
import re

from rentomatic.shared.domain_model import DomainModel


class StorageRoom(object):

    ISO_DATE_PATTERN = re.compile(r'^\d{4}-\d{2}-\d{2}$')

    def __init__(self, code, size, price, latitude, longitude, featured=False,
                 available_from=None, available_to=None):
        self.code = code
        self.size = size
        self.price = price
        self.latitude = latitude
        self.longitude = longitude
        self.featured = featured
        self.available_from = available_from
        self.available_to = available_to

    @classmethod
    def from_dict(cls, adict):
        room = StorageRoom(
            code=adict['code'],
            size=adict['size'],
            price=adict['price'],
            latitude=adict['latitude'],
            longitude=adict['longitude'],
            featured=adict.get('featured', False),
            available_from=adict.get('available_from', None),
            available_to=adict.get('available_to', None),
        )

        return room

    @classmethod
    def is_iso_date(cls, value):
        """Return True when value is a string in ISO YYYY-MM-DD format."""
        if not isinstance(value, str):
            return False

        if not cls.ISO_DATE_PATTERN.match(value):
            return False

        try:
            datetime.datetime.strptime(value, '%Y-%m-%d')
        except ValueError:
            return False

        return True

    def matches_availability_window(self, available_from=None,
                                    available_to=None):
        """Return True when the room's advertised window overlaps the
        requested window.

        Both windows are given as ISO date strings and the bounds are
        inclusive: the room matches when
        available_from <= requested_to and available_to >= requested_from.
        A room that does not advertise a complete window never matches.
        """
        if not self.available_from or not self.available_to:
            return False

        if available_to is not None and self.available_from > available_to:
            return False

        if available_from is not None and self.available_to < available_from:
            return False

        return True

    def to_dict(self):
        data = {
            'code': self.code,
            'size': self.size,
            'price': self.price,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'featured': self.featured,
        }

        if self.available_from is not None:
            data['available_from'] = self.available_from

        if self.available_to is not None:
            data['available_to'] = self.available_to

        return data

    def __eq__(self, other):
        return self.to_dict() == other.to_dict()


DomainModel.register(StorageRoom)
