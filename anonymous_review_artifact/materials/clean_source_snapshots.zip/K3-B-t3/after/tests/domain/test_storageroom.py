import uuid

import pytest

from rentomatic.domain.storageroom import StorageRoom


def test_storageroom_model_init():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=10,
                              longitude=-0.09998975,
                              latitude=51.75436293)
    assert storageroom.code == code
    assert storageroom.size == 200
    assert storageroom.price == 10
    assert storageroom.longitude == -0.09998975
    assert storageroom.latitude == 51.75436293
    assert storageroom.featured is False
    assert storageroom.available_from is None
    assert storageroom.available_to is None


def test_storageroom_model_init_featured():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=10,
                              longitude=-0.09998975,
                              latitude=51.75436293,
                              featured=True)
    assert storageroom.featured is True


def test_storageroom_model_init_availability_window():
    code = uuid.uuid4()
    storageroom = StorageRoom(code, size=200, price=10,
                              longitude=-0.09998975,
                              latitude=51.75436293,
                              available_from='2026-11-01',
                              available_to='2026-11-10')
    assert storageroom.available_from == '2026-11-01'
    assert storageroom.available_to == '2026-11-10'


def test_storageroom_model_from_dict():
    code = uuid.uuid4()
    storageroom = StorageRoom.from_dict(
        {
            'code': code,
            'size': 200,
            'price': 10,
            'longitude': -0.09998975,
            'latitude': 51.75436293
        }
    )
    assert storageroom.code == code
    assert storageroom.size == 200
    assert storageroom.price == 10
    assert storageroom.longitude == -0.09998975
    assert storageroom.latitude == 51.75436293
    assert storageroom.featured is False
    assert storageroom.available_from is None
    assert storageroom.available_to is None


def test_storageroom_model_from_dict_with_featured():
    code = uuid.uuid4()
    storageroom = StorageRoom.from_dict(
        {
            'code': code,
            'size': 200,
            'price': 10,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'featured': True
        }
    )
    assert storageroom.featured is True


def test_storageroom_model_from_dict_with_availability_window():
    code = uuid.uuid4()
    storageroom = StorageRoom.from_dict(
        {
            'code': code,
            'size': 200,
            'price': 10,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'available_from': '2026-11-01',
            'available_to': '2026-11-10'
        }
    )
    assert storageroom.available_from == '2026-11-01'
    assert storageroom.available_to == '2026-11-10'


def test_storageroom_model_to_dict():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': False
    }

    storageroom = StorageRoom.from_dict(storageroom_dict)

    assert storageroom.to_dict() == storageroom_dict


def test_storageroom_model_to_dict_featured():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': True
    }

    storageroom = StorageRoom.from_dict(storageroom_dict)

    assert storageroom.to_dict() == storageroom_dict


def test_storageroom_model_to_dict_with_availability_window():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': False,
        'available_from': '2026-11-01',
        'available_to': '2026-11-10'
    }

    storageroom = StorageRoom.from_dict(storageroom_dict)

    assert storageroom.to_dict() == storageroom_dict


def test_storageroom_model_comparison():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293
    }
    storageroom1 = StorageRoom.from_dict(storageroom_dict)
    storageroom2 = StorageRoom.from_dict(storageroom_dict)

    assert storageroom1 == storageroom2


def test_storageroom_model_comparison_featured():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293
    }
    storageroom1 = StorageRoom.from_dict(storageroom_dict)
    storageroom2 = StorageRoom.from_dict(
        dict(storageroom_dict, featured=True))

    assert storageroom1 != storageroom2


def test_storageroom_model_comparison_availability_window():
    storageroom_dict = {
        'code': uuid.uuid4(),
        'size': 200,
        'price': 10,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'available_from': '2026-11-01',
        'available_to': '2026-11-10'
    }
    storageroom1 = StorageRoom.from_dict(storageroom_dict)
    storageroom2 = StorageRoom.from_dict(
        dict(storageroom_dict, available_to='2026-11-11'))

    assert storageroom1 != storageroom2


def test_storageroom_model_is_iso_date_accepts_valid_dates():
    assert StorageRoom.is_iso_date('2026-11-01') is True
    assert StorageRoom.is_iso_date('2027-02-28') is True


def test_storageroom_model_is_iso_date_rejects_malformed_dates():
    assert StorageRoom.is_iso_date('2026-1-1') is False
    assert StorageRoom.is_iso_date('2026-13-01') is False
    assert StorageRoom.is_iso_date('2027-02-30') is False
    assert StorageRoom.is_iso_date('01-11-2026') is False
    assert StorageRoom.is_iso_date('2026-11-01T00:00:00') is False
    assert StorageRoom.is_iso_date('') is False
    assert StorageRoom.is_iso_date(None) is False
    assert StorageRoom.is_iso_date(20261101) is False


@pytest.mark.parametrize('requested_from,requested_to,expected', [
    # requested window contained in the room window
    ('2026-11-05', '2026-11-07', True),
    # requested window entirely before the room window
    ('2026-10-01', '2026-10-31', False),
    # requested window entirely after the room window
    ('2026-11-11', '2026-11-20', False),
    # requested window touching the room window start (inclusive)
    ('2026-10-25', '2026-11-01', True),
    # requested window touching the room window end (inclusive)
    ('2026-11-10', '2026-11-20', True),
    # requested window containing the whole room window
    ('2026-10-25', '2026-11-20', True),
    # identical windows
    ('2026-11-01', '2026-11-10', True),
])
def test_storageroom_model_availability_window_overlap(
        requested_from, requested_to, expected):
    room = StorageRoom(
        code=uuid.uuid4(),
        size=200,
        price=10,
        longitude=-0.09998975,
        latitude=51.75436293,
        available_from='2026-11-01',
        available_to='2026-11-10',
    )

    assert room.matches_availability_window(
        available_from=requested_from,
        available_to=requested_to) is expected


@pytest.mark.parametrize('requested_from,requested_to,expected', [
    # open-ended requested window overlapping the room window
    ('2026-11-05', None, True),
    # open-ended requested window not overlapping (ends before room starts)
    ('2026-11-11', None, False),
    # left-open requested window overlapping the room window
    (None, '2026-11-05', True),
    # left-open requested window not overlapping (starts after room ends)
    (None, '2026-10-31', False),
    # no bounds: every advertised room matches
    (None, None, True),
])
def test_storageroom_model_availability_window_open_bounds(
        requested_from, requested_to, expected):
    room = StorageRoom(
        code=uuid.uuid4(),
        size=200,
        price=10,
        longitude=-0.09998975,
        latitude=51.75436293,
        available_from='2026-11-01',
        available_to='2026-11-10',
    )

    assert room.matches_availability_window(
        available_from=requested_from,
        available_to=requested_to) is expected


def test_storageroom_model_availability_window_requires_full_window():
    room = StorageRoom(
        code=uuid.uuid4(),
        size=200,
        price=10,
        longitude=-0.09998975,
        latitude=51.75436293,
    )

    assert room.matches_availability_window(
        available_from='2026-11-05',
        available_to='2026-11-07') is False

    partial_room = StorageRoom(
        code=uuid.uuid4(),
        size=200,
        price=10,
        longitude=-0.09998975,
        latitude=51.75436293,
        available_from='2026-11-01',
    )

    assert partial_room.matches_availability_window(
        available_from='2026-11-05',
        available_to='2026-11-07') is False
