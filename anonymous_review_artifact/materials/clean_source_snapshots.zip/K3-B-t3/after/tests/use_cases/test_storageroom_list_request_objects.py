from rentomatic.use_cases import request_objects as ro


def test_build_storageroom_list_request_object_without_parameters():
    req = ro.StorageRoomListRequestObject()

    assert req.filters is None
    assert req.featured is None
    assert req.available_from is None
    assert req.available_to is None
    assert req.sort is None
    assert bool(req) is True


def test_build_file_list_request_object_from_empty_dict():
    req = ro.StorageRoomListRequestObject.from_dict({})

    assert req.filters is None
    assert req.featured is None
    assert req.available_from is None
    assert req.available_to is None
    assert req.sort is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_empty_filters():
    req = ro.StorageRoomListRequestObject(filters={})

    assert req.filters == {}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_empty_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': {}})

    assert req.filters == {}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_filters():
    req = ro.StorageRoomListRequestObject(filters={'a': 1, 'b': 2})

    assert req.filters == {'a': 1, 'b': 2}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': {'a': 1, 'b': 2}})

    assert req.filters == {'a': 1, 'b': 2}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': 5})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'filters'
    assert bool(req) is False


def test_build_storageroom_list_request_object_featured_true():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': True})

    assert req.filters is None
    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_featured_false():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': False})

    assert req.filters is None
    assert req.featured is False
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_filters_and_featured():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'a': 1}, 'featured': True})

    assert req.filters == {'a': 1}
    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_featured():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': 'true'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'featured'
    assert req.errors[0]['message'] == 'Is not a boolean'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_availability_window():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01', 'available_to': '2026-11-10'})

    assert req.available_from == '2026-11-01'
    assert req.available_to == '2026-11-10'
    assert req.sort is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_single_availability_bound():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01'})

    assert req.available_from == '2026-11-01'
    assert req.available_to is None
    assert bool(req) is True

    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_to': '2026-11-10'})

    assert req.available_from is None
    assert req.available_to == '2026-11-10'
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_availability_and_other_params():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 60},
         'featured': True,
         'available_from': '2026-11-01',
         'available_to': '2026-11-10'})

    assert req.filters == {'price__lt': 60}
    assert req.featured is True
    assert req.available_from == '2026-11-01'
    assert req.available_to == '2026-11-10'
    assert req.sort is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_malformed_available_from():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '01/11/2026'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert req.errors[0]['message'] == 'Is not a valid ISO date (YYYY-MM-DD)'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_malformed_available_to():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_to': '2026-13-40'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_to'
    assert req.errors[0]['message'] == 'Is not a valid ISO date (YYYY-MM-DD)'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_non_string_availability():
    req = ro.StorageRoomListRequestObject.from_dict({'available_from': 20261101})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert req.errors[0]['message'] == 'Is not a valid ISO date (YYYY-MM-DD)'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_multiple_malformed_dates():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': 'when', 'available_to': 'ever'})

    assert req.has_errors()
    assert [err['parameter'] for err in req.errors] == \
        ['available_from', 'available_to']
    assert all([err['message'] == 'Is not a valid ISO date (YYYY-MM-DD)'
                for err in req.errors])
    assert bool(req) is False


def test_malformed_dates_are_reported_together_with_other_errors():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': 5, 'available_from': 'when'})

    assert req.has_errors()
    assert [err['parameter'] for err in req.errors] == \
        ['filters', 'available_from']
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_sort_price_asc():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'price_asc'})

    assert req.sort == 'price_asc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_sort_price_desc():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'price_desc'})

    assert req.sort == 'price_desc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_sort_and_other_params():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 60},
         'featured': True,
         'sort': 'price_desc'})

    assert req.filters == {'price__lt': 60}
    assert req.featured is True
    assert req.sort == 'price_desc'
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_invalid_sort():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'price_up'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'sort'
    assert req.errors[0]['message'] == 'Is not a valid sort value ' \
        '(allowed values: price_asc, price_desc)'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_sort_is_case_sensitive():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 'PRICE_ASC'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'sort'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_non_string_sort():
    req = ro.StorageRoomListRequestObject.from_dict({'sort': 42})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'sort'
    assert bool(req) is False


def test_invalid_sort_is_reported_together_with_other_errors():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'featured': 'true', 'sort': 'nope'})

    assert req.has_errors()
    assert [err['parameter'] for err in req.errors] == ['featured', 'sort']
    assert bool(req) is False
