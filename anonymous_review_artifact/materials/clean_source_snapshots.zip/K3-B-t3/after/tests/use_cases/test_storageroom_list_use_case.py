import uuid

import pytest
from unittest import mock

from rentomatic.domain.storageroom import StorageRoom
from rentomatic.shared import response_object as res
from rentomatic.use_cases import request_objects as req
from rentomatic.use_cases import storageroom_use_cases as uc


@pytest.fixture
def domain_storagerooms():
    storageroom_1 = StorageRoom(
        code=uuid.uuid4(),
        size=215,
        price=39,
        longitude=-0.09998975,
        latitude=51.75436293,
        featured=True,
    )

    storageroom_2 = StorageRoom(
        code=uuid.uuid4(),
        size=405,
        price=66,
        longitude=0.18228006,
        latitude=51.74640997,
        featured=False,
    )

    storageroom_3 = StorageRoom(
        code=uuid.uuid4(),
        size=56,
        price=60,
        longitude=0.27891577,
        latitude=51.45994069,
        featured=False,
    )

    storageroom_4 = StorageRoom(
        code=uuid.uuid4(),
        size=93,
        price=48,
        longitude=0.33894476,
        latitude=51.39916678,
        featured=True,
    )

    return [storageroom_1, storageroom_2, storageroom_3, storageroom_4]


def test_storageroom_list_without_parameters(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters=None, sort=None)

    assert response_object.value == domain_storagerooms


def test_storageroom_list_with_filters(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    qry_filters = {'a': 5}
    request_object = req.StorageRoomListRequestObject.from_dict({'filters': qry_filters})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters=qry_filters, sort=None)
    assert response_object.value == domain_storagerooms


def test_storageroom_list_with_featured_true(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'featured': True})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters={'featured': True}, sort=None)
    assert response_object.value == domain_storagerooms


def test_storageroom_list_with_featured_false(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'featured': False})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters={'featured': False}, sort=None)
    assert response_object.value == domain_storagerooms


def test_storageroom_list_with_filters_and_featured(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    qry_filters = {'price__lt': 60}
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'filters': qry_filters, 'featured': True})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'price__lt': 60, 'featured': True}, sort=None)
    assert response_object.value == domain_storagerooms


def test_storageroom_list_with_featured_does_not_mutate_request_filters(
        domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'filters': {'a': 5}, 'featured': True})

    storageroom_list_use_case.execute(request_object)

    assert request_object.filters == {'a': 5}


def test_storageroom_list_with_availability_window(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01', 'available_to': '2026-11-10'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'available_from': '2026-11-01',
                 'available_to': '2026-11-10'},
        sort=None)
    assert response_object.value == domain_storagerooms


def test_storageroom_list_with_availability_window_and_filters(
        domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 60},
         'available_from': '2026-11-01',
         'available_to': '2026-11-10'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'price__lt': 60,
                 'available_from': '2026-11-01',
                 'available_to': '2026-11-10'},
        sort=None)
    assert response_object.value == domain_storagerooms


def test_storageroom_list_with_single_availability_bound(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01'})

    storageroom_list_use_case.execute(request_object)

    repo.list.assert_called_with(
        filters={'available_from': '2026-11-01'}, sort=None)

    request_object = req.StorageRoomListRequestObject.from_dict(
        {'available_to': '2026-11-10'})

    storageroom_list_use_case.execute(request_object)

    repo.list.assert_called_with(
        filters={'available_to': '2026-11-10'}, sort=None)


def test_storageroom_list_with_availability_does_not_mutate_request_filters(
        domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'filters': {'a': 5},
         'available_from': '2026-11-01',
         'available_to': '2026-11-10'})

    storageroom_list_use_case.execute(request_object)

    assert request_object.filters == {'a': 5}


def test_storageroom_list_with_sort_ascending(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'sort': 'price_asc'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters=None, sort='price_asc')
    assert response_object.value == domain_storagerooms


def test_storageroom_list_with_sort_descending(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'sort': 'price_desc'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(filters=None, sort='price_desc')
    assert response_object.value == domain_storagerooms


def test_storageroom_list_with_sort_and_filters(domain_storagerooms):
    repo = mock.Mock()
    repo.list.return_value = domain_storagerooms

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 60},
         'featured': True,
         'sort': 'price_desc'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is True
    repo.list.assert_called_with(
        filters={'price__lt': 60, 'featured': True},
        sort='price_desc')
    assert response_object.value == domain_storagerooms


def test_storageroom_list_handles_generic_error():
    repo = mock.Mock()
    repo.list.side_effect = Exception('Just an error message')

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    assert response_object.value == {
        'type': res.ResponseFailure.SYSTEM_ERROR,
        'message': "Exception: Just an error message"
    }


def test_storageroom_list_handles_bad_request():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict({'filters': 5})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': "filters: Is not iterable"
    }


def test_storageroom_list_handles_invalid_sort_value():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'sort': 'price_up'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': 'sort: Is not a valid sort value '
                   '(allowed values: price_asc, price_desc)'
    }
    repo.list.assert_not_called()


def test_storageroom_list_handles_malformed_availability_dates():
    repo = mock.Mock()

    storageroom_list_use_case = uc.StorageRoomListUseCase(repo)
    request_object = req.StorageRoomListRequestObject.from_dict(
        {'available_from': '31/12/2026'})

    response_object = storageroom_list_use_case.execute(request_object)

    assert bool(response_object) is False
    assert response_object.value == {
        'type': res.ResponseFailure.PARAMETERS_ERROR,
        'message': 'available_from: Is not a valid ISO date (YYYY-MM-DD)'
    }
    repo.list.assert_not_called()
