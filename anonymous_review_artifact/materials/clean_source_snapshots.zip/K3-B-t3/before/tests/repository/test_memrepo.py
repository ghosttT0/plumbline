import pytest

from rentomatic.domain.storageroom import StorageRoom
from rentomatic.shared.domain_model import DomainModel

from rentomatic.repository import memrepo


@pytest.fixture
def storageroom_dicts():
    return [
        {
            'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
            'size': 215,
            'price': 39,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'featured': True,
        },
        {
            'code': 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
            'size': 405,
            'price': 66,
            'longitude': 0.18228006,
            'latitude': 51.74640997,
            'featured': False,
        },
        {
            'code': '913694c6-435a-4366-ba0d-da5334a611b2',
            'size': 56,
            'price': 60,
            'longitude': 0.27891577,
            'latitude': 51.45994069,
            'featured': False,
        },
        {
            'code': 'eed76e77-55c1-41ce-985d-ca49bf6c0585',
            'size': 93,
            'price': 48,
            'longitude': 0.33894476,
            'latitude': 51.39916678,
            'featured': True,
        },
        {
            'code': '7bd99d70-5ec6-4dc4-9e3d-246b8e96c89d',
            'size': 26,
            'price': 19,
            'longitude': 0.12228006,
            'latitude': 51.54640997,
            'featured': False,
        }
    ]


@pytest.fixture
def storageroom_dicts_with_windows(storageroom_dicts):
    return [
        # window containing the queried window
        dict(storageroom_dicts[0],
             available_from='2026-10-01',
             available_to='2026-12-31'),
        # window contained in the queried window
        dict(storageroom_dicts[1],
             available_from='2026-11-05',
             available_to='2026-11-10'),
        # window ending exactly when the queried window starts (inclusive)
        dict(storageroom_dicts[2],
             available_from='2026-10-01',
             available_to='2026-11-01'),
        # window starting exactly when the queried window ends (inclusive)
        dict(storageroom_dicts[3],
             available_from='2026-11-30',
             available_to='2026-12-31'),
        # no advertised window
        storageroom_dicts[4],
    ]


def _check_results(domain_models_list, data_list):
    assert len(domain_models_list) == len(data_list)
    assert all([isinstance(dm, DomainModel) for dm in domain_models_list])
    assert set([dm.code for dm in domain_models_list]
               ) == set([d['code'] for d in data_list])


def test_repository_list_without_parameters(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(),
        storageroom_dicts
    )


def test_repository_list_with_filters_unknown_key(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    with pytest.raises(KeyError):
        repo.list(filters={'name': 'aname'})


def test_repository_list_with_filters_unknown_operator(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    with pytest.raises(ValueError):
        repo.list(filters={'price__in': [20, 30]})


def test_repository_list_with_filters_price(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'price': 60}),
        [storageroom_dicts[2]]
    )


def test_repository_list_with_filters_price_eq(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'price__eq': 60}),
        [storageroom_dicts[2]]
    )


def test_repository_list_with_filters_price_lt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'price__lt': 60}),
        [storageroom_dicts[0], storageroom_dicts[3], storageroom_dicts[4]])


def test_repository_list_with_filters_price_gt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)
    _check_results(
        repo.list(filters={'price__gt': 60}),
        [storageroom_dicts[1]]
    )


def test_repository_list_with_filters_size(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'size': 93}),
        [storageroom_dicts[3]]
    )


def test_repository_list_with_filters_size_eq(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)
    _check_results(
        repo.list(filters={'size__eq': 93}),
        [storageroom_dicts[3]]
    )


def test_repository_list_with_filters_size_lt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'size__lt': 60}),
        [storageroom_dicts[2], storageroom_dicts[4]]
    )


def test_repository_list_with_filters_size_gt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)
    _check_results(
        repo.list(filters={'size__gt': 400}),
        [storageroom_dicts[1]]
    )


def test_repository_list_with_filters_code(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'code': '913694c6-435a-4366-ba0d-da5334a611b2'}),
        [storageroom_dicts[2]]
    )


def test_repository_list_with_filters_featured_true(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'featured': True}),
        [storageroom_dicts[0], storageroom_dicts[3]]
    )


def test_repository_list_with_filters_featured_false(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'featured': False}),
        [storageroom_dicts[1], storageroom_dicts[2], storageroom_dicts[4]]
    )


def test_repository_list_with_filters_featured_eq(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'featured__eq': True}),
        [storageroom_dicts[0], storageroom_dicts[3]]
    )


def test_repository_list_with_filters_featured_and_price(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'featured': True, 'price__gt': 45}),
        [storageroom_dicts[3]]
    )


def test_repository_list_preserves_featured_attribute(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    result = repo.list()

    assert [dm.featured for dm in result] == \
        [d['featured'] for d in storageroom_dicts]


def test_repository_list_with_default_featured_attribute():
    repo = memrepo.MemRepo([{
        'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
        'size': 215,
        'price': 39,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
    }])

    result = repo.list()

    assert result[0] == StorageRoom.from_dict({
        'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
        'size': 215,
        'price': 39,
        'longitude': -0.09998975,
        'latitude': 51.75436293,
        'featured': False,
    })


def test_repository_list_preserves_availability_window(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    result = repo.list()

    assert [dm.available_from for dm in result] == \
        [d.get('available_from') for d in storageroom_dicts_with_windows]
    assert [dm.available_to for dm in result] == \
        [d.get('available_to') for d in storageroom_dicts_with_windows]


def test_repository_list_with_availability_window_containing_room_windows(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    # every room with a window overlapping [2026-11-01, 2026-11-30] matches
    _check_results(
        repo.list(filters={'available_from': '2026-11-01',
                           'available_to': '2026-11-30'}),
        storageroom_dicts_with_windows[:4]
    )


def test_repository_list_with_availability_window_disjoint_rooms(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    # a window after every advertised window matches no room
    _check_results(
        repo.list(filters={'available_from': '2027-01-01',
                           'available_to': '2027-01-31'}),
        []
    )

    # a window before every advertised window matches no room
    _check_results(
        repo.list(filters={'available_from': '2026-08-01',
                           'available_to': '2026-08-31'}),
        []
    )


def test_repository_list_with_availability_window_touching_bounds(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    # touching the end of a room window is an inclusive match
    _check_results(
        repo.list(filters={'available_from': '2026-10-20',
                           'available_to': '2026-11-01'}),
        [storageroom_dicts_with_windows[0],
         storageroom_dicts_with_windows[2]]
    )

    # touching the start of a room window is an inclusive match
    _check_results(
        repo.list(filters={'available_from': '2026-11-30',
                           'available_to': '2026-12-15'}),
        [storageroom_dicts_with_windows[0],
         storageroom_dicts_with_windows[3]]
    )


def test_repository_list_with_single_availability_bound(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    # requested [2026-11-10, oo): room windows ending on or after that date
    _check_results(
        repo.list(filters={'available_from': '2026-11-10'}),
        [storageroom_dicts_with_windows[0],
         storageroom_dicts_with_windows[1],
         storageroom_dicts_with_windows[3]]
    )

    # requested [2026-11-11, oo): the window ending 2026-11-10 is excluded
    _check_results(
        repo.list(filters={'available_from': '2026-11-11'}),
        [storageroom_dicts_with_windows[0],
         storageroom_dicts_with_windows[3]]
    )

    # requested (-oo, 2026-11-10]: room windows starting on or before it
    _check_results(
        repo.list(filters={'available_to': '2026-11-10'}),
        [storageroom_dicts_with_windows[0],
         storageroom_dicts_with_windows[1],
         storageroom_dicts_with_windows[2]]
    )


def test_repository_list_with_availability_window_excludes_rooms_without_window(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    result = repo.list(filters={'available_from': '2026-11-10'})

    assert storageroom_dicts_with_windows[4]['code'] not in \
        [dm.code for dm in result]


def test_repository_list_with_availability_window_and_other_filters(
        storageroom_dicts_with_windows):
    repo = memrepo.MemRepo(storageroom_dicts_with_windows)

    _check_results(
        repo.list(filters={'available_from': '2026-11-01',
                           'available_to': '2026-11-30',
                           'price__gt': 40}),
        [storageroom_dicts_with_windows[1],
         storageroom_dicts_with_windows[2],
         storageroom_dicts_with_windows[3]]
    )
