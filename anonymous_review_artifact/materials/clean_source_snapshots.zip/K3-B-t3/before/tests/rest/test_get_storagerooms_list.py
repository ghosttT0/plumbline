import json
from unittest import mock

from rentomatic.domain.storageroom import StorageRoom
from rentomatic.shared import response_object as res

storageroom1_dict = {
    'code': '3251a5bd-86be-428d-8ae9-6e51a8048c33',
    'size': 200,
    'price': 10,
    'longitude': -0.09998975,
    'latitude': 51.75436293,
    'featured': False,
}

storageroom1_domain_model = StorageRoom.from_dict(storageroom1_dict)

storagerooms = [storageroom1_domain_model]

seed_featured_codes = {
    'f853578c-fc0f-4e65-81b8-566c5dffa35a',
    'eed76e77-55c1-41ce-985d-ca49bf6c0585',
}

seed_not_featured_codes = {
    'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
    '913694c6-435a-4366-ba0d-da5334a611b2',
    '7bd99d70-5ec6-4dc4-9e3d-246b8e96c89d',
}

seed_window_codes = {
    'f853578c-fc0f-4e65-81b8-566c5dffa35a': ('2026-11-01', '2026-11-10'),
    '913694c6-435a-4366-ba0d-da5334a611b2': ('2026-12-01', '2026-12-15'),
    'eed76e77-55c1-41ce-985d-ca49bf6c0585': ('2027-01-05', '2027-01-06'),
}

seed_window_room_codes = set(seed_window_codes.keys())


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_get(mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess(storagerooms)

    http_response = client.get('/storagerooms')

    assert json.loads(http_response.data.decode(
        'UTF-8')) == [storageroom1_dict]
    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_get_failed_response(mock_use_case, client):
    mock_use_case().execute.return_value = \
        res.ResponseFailure.build_system_error('test message')

    http_response = client.get('/storagerooms')

    assert json.loads(http_response.data.decode('UTF-8')) == \
        {'type': 'SYSTEM_ERROR', 'message': 'test message'}
    assert http_response.status_code == 500
    assert http_response.mimetype == 'application/json'


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_filters(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?filter_param1=value1&filter_param2=value2')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {'param1': 'value1', 'param2': 'value2'}}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_featured_true(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?featured=true')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'featured': True}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_featured_false(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?featured=false')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'featured': False}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_availability_window(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get(
            '/storagerooms?available_from=2026-11-01&available_to=2026-11-10')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {},
         'available_from': '2026-11-01',
         'available_to': '2026-11-10'}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


def test_get_all_rooms_without_featured_parameter(client):
    http_response = client.get('/storagerooms')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'
    assert len(body) == 5
    assert set([room['code'] for room in body]) == \
        seed_featured_codes | seed_not_featured_codes


def test_get_advertised_availability_windows(client):
    http_response = client.get('/storagerooms')

    body = json.loads(http_response.data.decode('UTF-8'))

    advertised = {room['code']: (room.get('available_from'),
                                 room.get('available_to'))
                  for room in body}

    assert advertised == seed_window_codes | {
        'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a': (None, None),
        '7bd99d70-5ec6-4dc4-9e3d-246b8e96c89d': (None, None),
    }


def test_get_featured_rooms(client):
    http_response = client.get('/storagerooms?featured=true')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'
    assert len(body) == 2
    assert set([room['code'] for room in body]) == seed_featured_codes
    assert all([room['featured'] is True for room in body])


def test_get_not_featured_rooms(client):
    http_response = client.get('/storagerooms?featured=false')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'
    assert len(body) == 3
    assert set([room['code'] for room in body]) == seed_not_featured_codes
    assert all([room['featured'] is False for room in body])


def test_get_featured_rooms_combined_with_filters(client):
    http_response = client.get(
        '/storagerooms?featured=true&filter_price__gt=45')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert [room['code'] for room in body] == \
        ['eed76e77-55c1-41ce-985d-ca49bf6c0585']
    assert body[0]['featured'] is True


def test_get_rooms_with_invalid_featured_parameter(client):
    http_response = client.get('/storagerooms?featured=maybe')

    assert http_response.status_code == 400
    assert http_response.mimetype == 'application/json'
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'featured: Is not a boolean'
    }


def test_get_rooms_with_availability_window_overlapping(client):
    # the requested window intersects only the November room window
    http_response = client.get(
        '/storagerooms?available_from=2026-11-05&available_to=2026-11-07')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'
    assert set([room['code'] for room in body]) == \
        {'f853578c-fc0f-4e65-81b8-566c5dffa35a'}
    assert body[0]['available_from'] == '2026-11-01'
    assert body[0]['available_to'] == '2026-11-10'


def test_get_rooms_with_availability_window_containing_room_windows(client):
    # the requested window contains the December and January room windows
    http_response = client.get(
        '/storagerooms?available_from=2026-11-15&available_to=2027-01-10')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert set([room['code'] for room in body]) == {
        '913694c6-435a-4366-ba0d-da5334a611b2',
        'eed76e77-55c1-41ce-985d-ca49bf6c0585',
    }


def test_get_rooms_with_availability_window_touching_room_windows(client):
    # inclusive bounds: a room window ending exactly when the requested
    # window starts still matches
    http_response = client.get(
        '/storagerooms?available_from=2026-11-01&available_to=2026-11-01')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert set([room['code'] for room in body]) == \
        {'f853578c-fc0f-4e65-81b8-566c5dffa35a'}

    # inclusive bounds: a room window starting exactly when the requested
    # window ends still matches
    http_response = client.get(
        '/storagerooms?available_from=2026-12-01&available_to=2026-12-01')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert set([room['code'] for room in body]) == \
        {'913694c6-435a-4366-ba0d-da5334a611b2'}


def test_get_rooms_with_availability_window_disjoint(client):
    http_response = client.get(
        '/storagerooms?available_from=2026-09-01&available_to=2026-09-30')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert body == []


def test_get_rooms_with_single_availability_bound(client):
    # only available_from: room windows ending on or after the given date
    http_response = client.get('/storagerooms?available_from=2026-11-10')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert set([room['code'] for room in body]) == seed_window_room_codes

    # only available_to: room windows starting on or before the given date
    http_response = client.get('/storagerooms?available_to=2026-12-01')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert set([room['code'] for room in body]) == {
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',
        '913694c6-435a-4366-ba0d-da5334a611b2',
    }


def test_get_rooms_availability_window_combined_with_featured(client):
    http_response = client.get(
        '/storagerooms?featured=true'
        '&available_from=2026-11-05&available_to=2026-11-07')

    body = json.loads(http_response.data.decode('UTF-8'))

    assert http_response.status_code == 200
    assert [room['code'] for room in body] == \
        ['f853578c-fc0f-4e65-81b8-566c5dffa35a']
    assert body[0]['featured'] is True


def test_get_rooms_with_malformed_available_from(client):
    http_response = client.get('/storagerooms?available_from=31/12/2026')

    assert http_response.status_code == 400
    assert http_response.mimetype == 'application/json'
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_from: Is not a valid ISO date (YYYY-MM-DD)'
    }


def test_get_rooms_with_malformed_available_to(client):
    http_response = client.get('/storagerooms?available_to=2026-13-99')

    assert http_response.status_code == 400
    assert http_response.mimetype == 'application/json'
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_to: Is not a valid ISO date (YYYY-MM-DD)'
    }


def test_get_rooms_with_malformed_availability_window(client):
    http_response = client.get(
        '/storagerooms?available_from=yesterday&available_to=tomorrow')

    assert http_response.status_code == 400
    assert http_response.mimetype == 'application/json'
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_from: Is not a valid ISO date (YYYY-MM-DD)\n'
                   'available_to: Is not a valid ISO date (YYYY-MM-DD)'
    }
