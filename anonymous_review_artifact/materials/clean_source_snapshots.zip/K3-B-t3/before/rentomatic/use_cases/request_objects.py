import collections.abc

from rentomatic.domain import storageroom as sr
from rentomatic.shared import request_object as req


class StorageRoomListRequestObject(req.ValidRequestObject):

    def __init__(self, filters=None, featured=None, available_from=None,
                 available_to=None):
        self.filters = filters
        self.featured = featured
        self.available_from = available_from
        self.available_to = available_to

    @classmethod
    def from_dict(cls, adict):
        invalid_req = req.InvalidRequestObject()

        if 'filters' in adict and not isinstance(adict['filters'], collections.abc.Mapping):
            invalid_req.add_error('filters', 'Is not iterable')

        if 'featured' in adict and not isinstance(adict['featured'], bool):
            invalid_req.add_error('featured', 'Is not a boolean')

        for param in ['available_from', 'available_to']:
            if param in adict and not sr.StorageRoom.is_iso_date(adict[param]):
                invalid_req.add_error(
                    param, 'Is not a valid ISO date (YYYY-MM-DD)')

        if invalid_req.has_errors():
            return invalid_req

        return StorageRoomListRequestObject(
            filters=adict.get('filters', None),
            featured=adict.get('featured', None),
            available_from=adict.get('available_from', None),
            available_to=adict.get('available_to', None),
        )
