from rentomatic.domain import storageroom as sr


class MemRepo:

    AVAILABILITY_FILTER_KEYS = ('available_from', 'available_to')

    def __init__(self, entries=None):
        self._entries = []
        if entries:
            self._entries.extend(entries)

    def _check(self, element, key, value):
        if '__' not in key:
            key = key + '__eq'

        key, operator = key.split('__')

        if operator not in ['eq', 'lt', 'gt']:
            raise ValueError('Operator {} is not supported'.format(operator))

        operator = '__{}__'.format(operator)

        if key in ['size', 'price']:
            return getattr(element[key], operator)(int(value))
        elif key in ['latitude', 'longitude']:
            return getattr(element[key], operator)(float(value))

        return getattr(element[key], operator)(value)

    def _availability_filters(self, filters):
        return {
            key: filters[key]
            for key in self.AVAILABILITY_FILTER_KEYS
            if key in filters
        }

    def list(self, filters=None):
        filters = filters or {}

        availability_filters = self._availability_filters(filters)
        scalar_filters = {
            key: value
            for key, value in filters.items()
            if key not in availability_filters
        }

        entries = self._entries
        for key, value in scalar_filters.items():
            entries = [e for e in entries if self._check(e, key, value)]

        result = [sr.StorageRoom.from_dict(e) for e in entries]

        if availability_filters:
            result = [
                room for room in result
                if room.matches_availability_window(
                    availability_filters.get('available_from'),
                    availability_filters.get('available_to'))
            ]

        return result
