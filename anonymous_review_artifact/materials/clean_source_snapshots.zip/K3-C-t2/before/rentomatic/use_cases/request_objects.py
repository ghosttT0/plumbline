import collections.abc

from rentomatic.shared import request_object as req


class StorageRoomListRequestObject(req.ValidRequestObject):

    def __init__(self, filters=None, featured=None):
        self.filters = filters
        self.featured = featured

    @classmethod
    def from_dict(cls, adict):
        invalid_req = req.InvalidRequestObject()

        if 'filters' in adict and not isinstance(adict['filters'], collections.abc.Mapping):
            invalid_req.add_error('filters', 'Is not iterable')

        if 'featured' in adict and not isinstance(adict['featured'], bool):
            invalid_req.add_error('featured', 'Is not a boolean')

        if invalid_req.has_errors():
            return invalid_req

        return StorageRoomListRequestObject(
            filters=adict.get('filters', None),
            featured=adict.get('featured', None)
        )
