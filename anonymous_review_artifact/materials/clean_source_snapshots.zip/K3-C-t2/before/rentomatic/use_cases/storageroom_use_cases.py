from rentomatic.shared import use_case as uc
from rentomatic.shared import response_object as res


class StorageRoomListUseCase(uc.UseCase):

    def __init__(self, repo):
        self.repo = repo

    def process_request(self, request_object):
        filters = request_object.filters
        if request_object.featured is not None:
            filters = dict(filters or {})
            filters['featured'] = request_object.featured

        domain_storagerooms = self.repo.list(filters=filters)
        return res.ResponseSuccess(domain_storagerooms)
