import json
from unittest import mock

from rentomatic.domain.storageroom import StorageRoom
from rentomatic.shared import response_object as res

storageroom1_dict = {
    'code': '3251a5bd-86be-428d-8ae9-6e51a8048c33',
    'size': 200,
    'price': 10,
    'longitude': -0.09998975,
    'latitude': 51.75436293,
    'featured': False
}

storageroom1_domain_model = StorageRoom.from_dict(storageroom1_dict)

storagerooms = [storageroom1_domain_model]

seed_featured_codes = {
    'f853578c-fc0f-4e65-81b8-566c5dffa35a',
    'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
}

seed_non_featured_codes = {
    '913694c6-435a-4366-ba0d-da5334a611b2',
    'eed76e77-55c1-41ce-985d-ca49bf6c0585',
    '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',
}


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_get(mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess(storagerooms)

    http_response = client.get('/storagerooms')

    assert json.loads(http_response.data.decode(
        'UTF-8')) == [storageroom1_dict]
    assert http_response.status_code == 200
    assert http_response.mimetype == 'application/json'


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_get_failed_response(mock_use_case, client):
    mock_use_case().execute.return_value = \
        res.ResponseFailure.build_system_error('test message')

    http_response = client.get('/storagerooms')

    assert json.loads(http_response.data.decode('UTF-8')) == \
        {'type': 'SYSTEM_ERROR', 'message': 'test message'}
    assert http_response.status_code == 500
    assert http_response.mimetype == 'application/json'


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_filters(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?filter_param1=value1&filter_param2=value2')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {'param1': 'value1', 'param2': 'value2'}}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_featured_true(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?featured=true')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'featured': True}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_featured_false(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get('/storagerooms?featured=false')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'featured': False}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


@mock.patch(
    'rentomatic.use_cases.storageroom_use_cases.StorageRoomListUseCase')
def test_request_object_initialisation_and_use_with_availability_window(
        mock_use_case, client):
    mock_use_case().execute.return_value = res.ResponseSuccess([])

    internal_request_object = mock.Mock()

    request_object_class = \
        'rentomatic.use_cases.request_objects.StorageRoomListRequestObject'
    with mock.patch(request_object_class) as mock_request_object:
        mock_request_object.from_dict.return_value = internal_request_object
        client.get(
            '/storagerooms?available_from=2026-11-01&available_to=2026-11-15')

    mock_request_object.from_dict.assert_called_with(
        {'filters': {}, 'available_from': '2026-11-01',
         'available_to': '2026-11-15'}
    )
    mock_use_case().execute.assert_called_with(internal_request_object)


def test_get_all_rooms_when_featured_parameter_is_absent(client):
    http_response = client.get('/storagerooms')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert len(body) == 5
    assert set([room['code'] for room in body]) == \
        seed_featured_codes | seed_non_featured_codes
    assert all('featured' in room for room in body)


def test_get_all_rooms_advertise_their_availability(client):
    http_response = client.get('/storagerooms')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    by_code = {room['code']: room for room in body}

    assert by_code['f853578c-fc0f-4e65-81b8-566c5dffa35a'][  # room1
        'available_from'] == '2026-11-01'
    assert by_code['f853578c-fc0f-4e65-81b8-566c5dffa35a'][  # room1
        'available_to'] == '2026-11-15'
    assert by_code['913694c6-435a-4366-ba0d-da5334a611b2'][  # room3
        'available_from'] == '2026-11-10'
    assert 'available_to' not in \
        by_code['913694c6-435a-4366-ba0d-da5334a611b2']
    assert 'available_from' not in \
        by_code['1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a']  # room5
    assert 'available_to' not in \
        by_code['1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a']


def test_get_featured_rooms(client):
    http_response = client.get('/storagerooms?featured=true')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert len(body) == 2
    assert set([room['code'] for room in body]) == seed_featured_codes
    assert all(room['featured'] is True for room in body)


def test_get_non_featured_rooms(client):
    http_response = client.get('/storagerooms?featured=false')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert len(body) == 3
    assert set([room['code'] for room in body]) == seed_non_featured_codes
    assert all(room['featured'] is False for room in body)


def test_get_rooms_with_featured_and_filters(client):
    http_response = client.get('/storagerooms?featured=true&filter_price=66')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert len(body) == 1
    assert body[0]['code'] == 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a'
    assert body[0]['featured'] is True


def test_get_rooms_available_in_window(client):
    http_response = client.get(
        '/storagerooms?available_from=2026-11-10&available_to=2026-11-20')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    # room2 ([2026-12-01, 2026-12-20]) does not overlap the window
    assert set([room['code'] for room in body]) == {
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',   # [2026-11-01, 2026-11-15]
        '913694c6-435a-4366-ba0d-da5334a611b2',   # from 2026-11-10 on
        'eed76e77-55c1-41ce-985d-ca49bf6c0585',   # until 2026-11-30
        '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',   # no availability advertised
    }


def test_get_rooms_available_in_window_boundaries_are_inclusive(client):
    # the requested window touches room1 at its end and room2 at its start
    http_response = client.get(
        '/storagerooms?available_from=2026-11-15&available_to=2026-12-01')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert 'f853578c-fc0f-4e65-81b8-566c5dffa35a' in \
        [room['code'] for room in body]
    assert 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a' in \
        [room['code'] for room in body]
    assert len(body) == 5


def test_get_rooms_available_after_date(client):
    http_response = client.get('/storagerooms?available_from=2026-12-01')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert set([room['code'] for room in body]) == {
        'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',   # [2026-12-01, 2026-12-20]
        '913694c6-435a-4366-ba0d-da5334a611b2',   # from 2026-11-10 on
        '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',   # no availability advertised
    }


def test_get_rooms_available_before_date(client):
    http_response = client.get('/storagerooms?available_to=2026-11-20')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert set([room['code'] for room in body]) == {
        'f853578c-fc0f-4e65-81b8-566c5dffa35a',   # [2026-11-01, 2026-11-15]
        '913694c6-435a-4366-ba0d-da5334a611b2',   # from 2026-11-10 on
        'eed76e77-55c1-41ce-985d-ca49bf6c0585',   # until 2026-11-30
        '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',   # no availability advertised
    }


def test_get_rooms_available_in_disjoint_window(client):
    http_response = client.get(
        '/storagerooms?available_from=2027-01-10&available_to=2027-01-20')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    # only rooms with an unbounded availability side can match
    assert set([room['code'] for room in body]) == {
        '913694c6-435a-4366-ba0d-da5334a611b2',
        '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',
    }


def test_get_with_availability_and_featured(client):
    http_response = client.get(
        '/storagerooms?featured=true&available_from=2026-11-10'
        '&available_to=2026-11-20')

    assert http_response.status_code == 200
    body = json.loads(http_response.data.decode('UTF-8'))

    assert [room['code'] for room in body] == \
        ['f853578c-fc0f-4e65-81b8-566c5dffa35a']


def test_get_with_malformed_available_from(client):
    http_response = client.get('/storagerooms?available_from=15/11/2026')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_from: Is not a valid ISO date (YYYY-MM-DD)'
    }


def test_get_with_malformed_available_to(client):
    http_response = client.get('/storagerooms?available_to=2026-02-30')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_to: Is not a valid ISO date (YYYY-MM-DD)'
    }


def test_get_with_malformed_availability_window(client):
    http_response = client.get(
        '/storagerooms?available_from=not-a-date&available_to=not-a-date')

    assert http_response.status_code == 400
    assert json.loads(http_response.data.decode('UTF-8')) == {
        'type': 'PARAMETERS_ERROR',
        'message': 'available_from: Is not a valid ISO date (YYYY-MM-DD)\n'
                   'available_to: Is not a valid ISO date (YYYY-MM-DD)'
    }
