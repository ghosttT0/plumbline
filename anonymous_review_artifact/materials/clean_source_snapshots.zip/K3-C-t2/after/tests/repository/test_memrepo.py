import datetime

import pytest

from rentomatic.domain.storageroom import StorageRoom
from rentomatic.shared.domain_model import DomainModel

from rentomatic.repository import memrepo


@pytest.fixture
def storageroom_dicts():
    return [
        {
            'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
            'size': 215,
            'price': 39,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
        },
        {
            'code': 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
            'size': 405,
            'price': 66,
            'longitude': 0.18228006,
            'latitude': 51.74640997,
        },
        {
            'code': '913694c6-435a-4366-ba0d-da5334a611b2',
            'size': 56,
            'price': 60,
            'longitude': 0.27891577,
            'latitude': 51.45994069,
        },
        {
            'code': 'eed76e77-55c1-41ce-985d-ca49bf6c0585',
            'size': 93,
            'price': 48,
            'longitude': 0.33894476,
            'latitude': 51.39916678,
        }
    ]


@pytest.fixture
def featured_storageroom_dicts():
    return [
        {
            'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
            'size': 215,
            'price': 39,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'featured': True,
        },
        {
            'code': 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
            'size': 405,
            'price': 66,
            'longitude': 0.18228006,
            'latitude': 51.74640997,
            'featured': False,
        },
        {
            'code': '913694c6-435a-4366-ba0d-da5334a611b2',
            'size': 56,
            'price': 60,
            'longitude': 0.27891577,
            'latitude': 51.45994069,
            'featured': True,
        },
        {
            # no "featured" key: the room is implicitly not featured
            'code': 'eed76e77-55c1-41ce-985d-ca49bf6c0585',
            'size': 93,
            'price': 48,
            'longitude': 0.33894476,
            'latitude': 51.39916678,
        },
    ]


@pytest.fixture
def availability_storageroom_dicts():
    return [
        {
            # bounded window [2026-11-01, 2026-11-15]
            'code': 'f853578c-fc0f-4e65-81b8-566c5dffa35a',
            'size': 215,
            'price': 39,
            'longitude': -0.09998975,
            'latitude': 51.75436293,
            'available_from': '2026-11-01',
            'available_to': '2026-11-15',
        },
        {
            # bounded window [2026-12-01, 2026-12-20]
            'code': 'fe2c3195-aeff-487a-a08f-e0bdc0ec6e9a',
            'size': 405,
            'price': 66,
            'longitude': 0.18228006,
            'latitude': 51.74640997,
            'available_from': '2026-12-01',
            'available_to': '2026-12-20',
        },
        {
            # unbounded after 2026-11-10
            'code': '913694c6-435a-4366-ba0d-da5334a611b2',
            'size': 56,
            'price': 60,
            'longitude': 0.27891577,
            'latitude': 51.45994069,
            'available_from': '2026-11-10',
        },
        {
            # unbounded before 2026-11-30
            'code': 'eed76e77-55c1-41ce-985d-ca49bf6c0585',
            'size': 93,
            'price': 48,
            'longitude': 0.33894476,
            'latitude': 51.39916678,
            'available_to': '2026-11-30',
        },
        {
            # no availability window: always matches
            'code': '1d88db2e-0a7e-4d0e-9c1d-2ee6f8a4b16a',
            'size': 26,
            'price': 23,
            'longitude': -0.12766808,
            'latitude': 51.49866124,
        },
    ]


def _check_results(domain_models_list, data_list):
    assert len(domain_models_list) == len(data_list)
    assert all([isinstance(dm, DomainModel) for dm in domain_models_list])
    assert set([dm.code for dm in domain_models_list]
               ) == set([d['code'] for d in data_list])


def test_repository_list_without_parameters(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(),
        storageroom_dicts
    )


def test_repository_list_with_filters_unknown_key(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    with pytest.raises(KeyError):
        repo.list(filters={'name': 'aname'})


def test_repository_list_with_filters_unknown_operator(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    with pytest.raises(ValueError):
        repo.list(filters={'price__in': [20, 30]})


def test_repository_list_with_filters_price(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'price': 60}),
        [storageroom_dicts[2]]
    )


def test_repository_list_with_filters_price_eq(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'price__eq': 60}),
        [storageroom_dicts[2]]
    )


def test_repository_list_with_filters_price_lt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'price__lt': 60}),
        [storageroom_dicts[0], storageroom_dicts[3]])


def test_repository_list_with_filters_price_gt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)
    _check_results(
        repo.list(filters={'price__gt': 60}),
        [storageroom_dicts[1]]
    )


def test_repository_list_with_filters_size(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'size': 93}),
        [storageroom_dicts[3]]
    )


def test_repository_list_with_filters_size_eq(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)
    _check_results(
        repo.list(filters={'size__eq': 93}),
        [storageroom_dicts[3]]
    )


def test_repository_list_with_filters_size_lt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'size__lt': 60}),
        [storageroom_dicts[2]]
    )


def test_repository_list_with_filters_size_gt(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)
    _check_results(
        repo.list(filters={'size__gt': 400}),
        [storageroom_dicts[1]]
    )


def test_repository_list_with_filters_code(storageroom_dicts):
    repo = memrepo.MemRepo(storageroom_dicts)

    _check_results(
        repo.list(filters={'code': '913694c6-435a-4366-ba0d-da5334a611b2'}),
        [storageroom_dicts[2]]
    )


def test_repository_list_with_filters_featured_true(featured_storageroom_dicts):
    repo = memrepo.MemRepo(featured_storageroom_dicts)

    _check_results(
        repo.list(filters={'featured': True}),
        [featured_storageroom_dicts[0], featured_storageroom_dicts[2]]
    )


def test_repository_list_with_filters_featured_false(featured_storageroom_dicts):
    repo = memrepo.MemRepo(featured_storageroom_dicts)

    _check_results(
        repo.list(filters={'featured': False}),
        [featured_storageroom_dicts[1], featured_storageroom_dicts[3]]
    )


def test_repository_list_with_filters_featured_eq(featured_storageroom_dicts):
    repo = memrepo.MemRepo(featured_storageroom_dicts)

    _check_results(
        repo.list(filters={'featured__eq': True}),
        [featured_storageroom_dicts[0], featured_storageroom_dicts[2]]
    )


def test_repository_list_with_filters_featured_string_value(
        featured_storageroom_dicts):
    repo = memrepo.MemRepo(featured_storageroom_dicts)

    _check_results(
        repo.list(filters={'featured': 'true'}),
        [featured_storageroom_dicts[0], featured_storageroom_dicts[2]]
    )


def test_repository_list_rooms_without_featured_key_are_not_featured(
        featured_storageroom_dicts):
    repo = memrepo.MemRepo(featured_storageroom_dicts)

    domain_models = repo.list()

    assert [dm.featured for dm in domain_models] == [True, False, True, False]


def test_repository_list_with_availability_window_string_values(
        availability_storageroom_dicts):
    # requested window [2026-11-10, 2026-11-20]: only the second room
    # ([2026-12-01, 2026-12-20]) does not overlap it
    repo = memrepo.MemRepo(availability_storageroom_dicts)

    _check_results(
        repo.list(filters={
            'available_from__lte': '2026-11-20',
            'available_to__gte': '2026-11-10',
        }),
        [availability_storageroom_dicts[0],
         availability_storageroom_dicts[2],
         availability_storageroom_dicts[3],
         availability_storageroom_dicts[4]]
    )


def test_repository_list_with_availability_window_date_values(
        availability_storageroom_dicts):
    repo = memrepo.MemRepo(availability_storageroom_dicts)

    _check_results(
        repo.list(filters={
            'available_from__lte': datetime.date(2026, 11, 20),
            'available_to__gte': datetime.date(2026, 11, 10),
        }),
        [availability_storageroom_dicts[0],
         availability_storageroom_dicts[2],
         availability_storageroom_dicts[3],
         availability_storageroom_dicts[4]]
    )


def test_repository_list_with_availability_window_overlap_is_inclusive(
        availability_storageroom_dicts):
    # the requested window touches the first room window at both ends
    repo = memrepo.MemRepo(availability_storageroom_dicts)

    _check_results(
        repo.list(filters={
            'available_from__lte': '2026-11-15',
            'available_to__gte': '2026-11-01',
        }),
        [availability_storageroom_dicts[0],
         availability_storageroom_dicts[2],
         availability_storageroom_dicts[3],
         availability_storageroom_dicts[4]]
    )


def test_repository_list_with_availability_window_no_overlap(
        availability_storageroom_dicts):
    # a window after the first room availability and before the second one
    repo = memrepo.MemRepo(availability_storageroom_dicts)

    _check_results(
        repo.list(filters={
            'available_from__lte': '2026-11-25',
            'available_to__gte': '2026-11-16',
        }),
        [availability_storageroom_dicts[2],
         availability_storageroom_dicts[3],
         availability_storageroom_dicts[4]]
    )


def test_repository_list_with_available_from_only(availability_storageroom_dicts):
    # rooms that are still available on 2026-12-01: the first room
    # (available_to 2026-11-15) and the fourth one (available_to
    # 2026-11-30) are excluded, unbounded rooms are kept
    repo = memrepo.MemRepo(availability_storageroom_dicts)

    _check_results(
        repo.list(filters={'available_to__gte': '2026-12-01'}),
        [availability_storageroom_dicts[1],
         availability_storageroom_dicts[2],
         availability_storageroom_dicts[4]]
    )


def test_repository_list_with_available_to_only(availability_storageroom_dicts):
    # rooms available before 2026-11-20: the second room (available_from
    # 2026-12-01) is excluded, unbounded rooms are kept
    repo = memrepo.MemRepo(availability_storageroom_dicts)

    _check_results(
        repo.list(filters={'available_from__lte': '2026-11-20'}),
        [availability_storageroom_dicts[0],
         availability_storageroom_dicts[2],
         availability_storageroom_dicts[3],
         availability_storageroom_dicts[4]]
    )


def test_repository_list_with_room_with_malformed_availability_is_not_excluded(
        availability_storageroom_dicts):
    entries = availability_storageroom_dicts[:1] + [{
        'code': '0f8c4b1e-0b7e-4f4e-9f0a-3f1d0f4b2c9d',
        'size': 100,
        'price': 30,
        'longitude': 0.1,
        'latitude': 51.5,
        'available_from': 'not-a-date',
    }]
    repo = memrepo.MemRepo(entries)

    _check_results(
        repo.list(filters={
            'available_from__lte': '2026-11-20',
            'available_to__gte': '2026-11-10',
        }),
        entries
    )


def test_repository_list_with_availability_unknown_operator(
        availability_storageroom_dicts):
    repo = memrepo.MemRepo(availability_storageroom_dicts)

    with pytest.raises(ValueError):
        repo.list(filters={'available_from__in': ['2026-11-01']})
