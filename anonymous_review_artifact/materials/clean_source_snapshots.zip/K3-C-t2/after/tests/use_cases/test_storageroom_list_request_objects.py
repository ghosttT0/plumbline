import datetime

from rentomatic.use_cases import request_objects as ro


def test_build_storageroom_list_request_object_without_parameters():
    req = ro.StorageRoomListRequestObject()

    assert req.filters is None
    assert req.featured is None
    assert req.available_from is None
    assert req.available_to is None
    assert bool(req) is True


def test_build_file_list_request_object_from_empty_dict():
    req = ro.StorageRoomListRequestObject.from_dict({})

    assert req.filters is None
    assert req.featured is None
    assert req.available_from is None
    assert req.available_to is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_empty_filters():
    req = ro.StorageRoomListRequestObject(filters={})

    assert req.filters == {}
    assert req.featured is None
    assert req.available_from is None
    assert req.available_to is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_empty_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': {}})

    assert req.filters == {}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_filters():
    req = ro.StorageRoomListRequestObject(filters={'a': 1, 'b': 2})

    assert req.filters == {'a': 1, 'b': 2}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': {'a': 1, 'b': 2}})

    assert req.filters == {'a': 1, 'b': 2}
    assert req.featured is None
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_filters():
    req = ro.StorageRoomListRequestObject.from_dict({'filters': 5})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'filters'
    assert bool(req) is False


def test_build_storageroom_list_request_object_with_featured():
    req = ro.StorageRoomListRequestObject(featured=True)

    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_featured():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': True})

    assert req.filters is None
    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_featured_false():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': False})

    assert req.featured is False
    assert bool(req) is True


def test_build_storageroom_list_request_object_with_filters_and_featured():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'filters': {'price__lt': 60}, 'featured': True})

    assert req.filters == {'price__lt': 60}
    assert req.featured is True
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_invalid_featured():
    req = ro.StorageRoomListRequestObject.from_dict({'featured': 'true'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'featured'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_available_from():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01'})

    assert bool(req) is True
    assert req.available_from == datetime.date(2026, 11, 1)
    assert req.available_to is None


def test_build_storageroom_list_request_object_from_dict_with_available_to():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_to': '2026-11-15'})

    assert bool(req) is True
    assert req.available_from is None
    assert req.available_to == datetime.date(2026, 11, 15)


def test_build_storageroom_list_request_object_from_dict_with_availability_window():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-01', 'available_to': '2026-11-15'})

    assert bool(req) is True
    assert req.available_from == datetime.date(2026, 11, 1)
    assert req.available_to == datetime.date(2026, 11, 15)


def test_build_storageroom_list_request_object_with_availability_window():
    req = ro.StorageRoomListRequestObject(
        available_from=datetime.date(2026, 11, 1),
        available_to=datetime.date(2026, 11, 15))

    assert req.available_from == datetime.date(2026, 11, 1)
    assert req.available_to == datetime.date(2026, 11, 15)
    assert bool(req) is True


def test_build_storageroom_list_request_object_from_dict_with_malformed_available_from():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '15/11/2026'})

    assert req.has_errors()
    assert req.errors == [{
        'parameter': 'available_from',
        'message': 'Is not a valid ISO date (YYYY-MM-DD)'
    }]
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_malformed_available_to():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_to': 'not-a-date'})

    assert req.has_errors()
    assert req.errors == [{
        'parameter': 'available_to',
        'message': 'Is not a valid ISO date (YYYY-MM-DD)'
    }]
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_invalid_calendar_date():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-02-30'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_zero_padded_date():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': '2026-11-1'})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert bool(req) is False


def test_build_storageroom_list_request_object_from_dict_with_non_string_date():
    req = ro.StorageRoomListRequestObject.from_dict({'available_from': 20261101})

    assert req.has_errors()
    assert req.errors[0]['parameter'] == 'available_from'
    assert bool(req) is False


def test_build_storageroom_list_request_object_accumulates_malformed_dates():
    req = ro.StorageRoomListRequestObject.from_dict(
        {'available_from': 'foo', 'available_to': 'bar'})

    assert req.has_errors()
    assert [err['parameter'] for err in req.errors] == \
        ['available_from', 'available_to']
    assert bool(req) is False
