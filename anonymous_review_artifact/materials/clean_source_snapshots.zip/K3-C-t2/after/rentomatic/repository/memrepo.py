import datetime

from rentomatic.domain import storageroom as sr

_OPERATORS = {
    'eq': '__eq__',
    'lt': '__lt__',
    'gt': '__gt__',
    'lte': '__le__',
    'gte': '__ge__',
}

_DATE_KEYS = ['available_from', 'available_to']


def _as_date(value):
    """Coerce a value into a ``datetime.date`` (returns None if impossible)."""
    if isinstance(value, datetime.datetime):
        return value.date()

    if isinstance(value, datetime.date):
        return value

    if isinstance(value, str):
        try:
            return datetime.datetime.strptime(value.strip(), '%Y-%m-%d').date()
        except ValueError:
            return None

    return None


class MemRepo:

    def __init__(self, entries=None):
        self._entries = []
        if entries:
            self._entries.extend(entries)

    def _check(self, element, key, value):
        if '__' not in key:
            key = key + '__eq'

        key, operator = key.split('__')

        if operator not in _OPERATORS:
            raise ValueError('Operator {} is not supported'.format(operator))

        operator = _OPERATORS[operator]

        if key in ['size', 'price']:
            return getattr(element[key], operator)(int(value))
        elif key in ['latitude', 'longitude']:
            return getattr(element[key], operator)(float(value))
        elif key == 'featured':
            if isinstance(value, str):
                value = value.strip().lower() == 'true'
            return getattr(element.get('featured', False), operator)(value)
        elif key in _DATE_KEYS:
            bound = _as_date(element.get(key, None))
            value = _as_date(value)

            if bound is None or value is None:
                # The room does not restrict this side of its availability
                # window (or the stored value cannot be parsed), so this
                # condition cannot exclude the room.
                return True

            return getattr(bound, operator)(value)

        return getattr(element[key], operator)(value)

    def list(self, filters=None):
        if not filters:
            result = self._entries
        else:
            result = []
            result.extend(self._entries)

            for key, value in filters.items():
                result = [e for e in result if self._check(e, key, value)]

        return [sr.StorageRoom.from_dict(r) for r in result]
