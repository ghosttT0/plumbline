import collections.abc
import datetime
import re

from rentomatic.shared import request_object as req

_ISO_DATE_REGEX = re.compile(r'^\d{4}-\d{2}-\d{2}$')


def parse_iso_date(value):
    """Parse a strictly-formatted ISO date string (YYYY-MM-DD).

    Returns a ``datetime.date`` or ``None`` when the value is not a
    valid ISO date.
    """
    if not isinstance(value, str) or not _ISO_DATE_REGEX.match(value):
        return None

    try:
        return datetime.datetime.strptime(value, '%Y-%m-%d').date()
    except ValueError:
        return None


class StorageRoomListRequestObject(req.ValidRequestObject):

    def __init__(self, filters=None, featured=None,
                 available_from=None, available_to=None):
        self.filters = filters
        self.featured = featured
        self.available_from = available_from
        self.available_to = available_to

    @classmethod
    def from_dict(cls, adict):
        invalid_req = req.InvalidRequestObject()

        if 'filters' in adict and not isinstance(adict['filters'], collections.abc.Mapping):
            invalid_req.add_error('filters', 'Is not iterable')

        if 'featured' in adict and not isinstance(adict['featured'], bool):
            invalid_req.add_error('featured', 'Is not a boolean')

        parsed_dates = {}
        for param in ['available_from', 'available_to']:
            if adict.get(param, None) is not None:
                parsed_dates[param] = parse_iso_date(adict[param])
                if parsed_dates[param] is None:
                    invalid_req.add_error(
                        param, 'Is not a valid ISO date (YYYY-MM-DD)')

        if invalid_req.has_errors():
            return invalid_req

        return StorageRoomListRequestObject(
            filters=adict.get('filters', None),
            featured=adict.get('featured', None),
            available_from=parsed_dates.get('available_from', None),
            available_to=parsed_dates.get('available_to', None)
        )
